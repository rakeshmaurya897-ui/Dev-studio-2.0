import { BedrockRuntimeClient, InvokeModelCommand } from "@aws-sdk/client-bedrock-runtime";

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method Not Allowed' });

  try {
    const { prompt } = req.body;
    const customKey = req.headers['x-custom-key'];

    if (!prompt || !prompt.trim()) {
      return res.status(400).json({ error: "Prompt cannot be empty!" });
    }

    const systemPrompt = "You are an expert Frontend Developer. Return ONLY clean, valid, fully responsive HTML code with Tailwind CSS CDN. Do not include markdown formatting like ```html. Do not explain the code.";

    // 1. कस्टमर की खुद की Key (BYOK)
    if (customKey) {
      const aiResponse = await fetch("[https://api.anthropic.com/v1/messages](https://api.anthropic.com/v1/messages)", {
        method: "POST",
        headers: {
          "x-api-key": customKey,
          "anthropic-version": "2023-06-01",
          "content-type": "application/json"
        },
        body: JSON.stringify({
          model: "claude-3-5-sonnet-20240620", 
          max_tokens: 4000,
          temperature: 0.2,
          system: systemPrompt,
          messages: [{ role: "user", content: prompt }]
        })
      });
      const data = await aiResponse.json();
      if (!aiResponse.ok) throw new Error(data.error?.message || "Anthropic BYOK Error");
      return res.status(200).json(data);
    }

    // 2. आपका AWS Bedrock (Pro/Starter Users के लिए)
    const client = new BedrockRuntimeClient({
      region: process.env.AWS_REGION || "us-east-1",
      credentials: {
        accessKeyId: process.env.AWS_ACCESS_KEY_ID,
        secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
      },
    });

    const bedrockPayload = {
      anthropic_version: "bedrock-2023-05-31",
      max_tokens: 4000,
      temperature: 0.2,
      system: systemPrompt,
      messages: [{ role: "user", content: prompt }]
    };

    // 👇 यहाँ मैंने वो असली मॉडल ID डाल दी है जो आपने निकाली!
    const command = new InvokeModelCommand({
      modelId: "us.anthropic.claude-sonnet-4-6", 
      contentType: "application/json",
      accept: "application/json",
      body: JSON.stringify(bedrockPayload),
    });

    const response = await client.send(command);
    const responseBody = JSON.parse(new TextDecoder().decode(response.body));

    return res.status(200).json(responseBody);

  } catch (error) {
    console.error("AI Generation Error:", error);
    return res.status(500).json({ error: "Failed to generate website. Please try again." });
  }
}
