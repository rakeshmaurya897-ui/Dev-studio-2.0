import React, { useState, useRef, useEffect } from "react";
import JSZip from "jszip";
import { saveAs } from "file-saver";
import { I } from "./ui";
import { CONFIG, sb, openPhonePe } from "./config";

const highlightHTML = (code) => {
  if (!code) return "";
  let h = code.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  h = h.replace(/(&lt;\/?)([a-zA-Z0-9\-]+)/g, "$1<span style='color:#f472b6; font-weight:600;'>$2</span>");
  h = h.replace(/([a-zA-Z0-9\-]+)=("[^"]*"|'[^']*')/g, "<span style='color:#22d3ee'>$1</span>=<span style='color:#f59e0b'>$2</span>");
  return h;
};

const PublishModal = ({ user, onClose, notify }) => {
  const [domain, setDomain] = useState("");
  const [saving, setSaving] = useState(false);

  const handleLinkDomain = async () => {
    if (!domain.trim()) return notify("Please enter your domain first! 🌐", "warning");
    if (!domain.includes(".")) return notify("Invalid domain format (use e.g., www.mygym.com)", "error");
    
    setSaving(true);
    try {
      if (!user?.id) throw new Error("Please log in to publish your site.");
      const cleanDomain = domain.trim().toLowerCase();
      await sb.saveDomain(user.id, cleanDomain, user?.token);
      notify("Domain saved successfully! 🎉 DNS Setup pending.", "success");
      onClose();
    } catch (err) {
      if (err.message?.includes("unique") || err.message?.includes("already exists")) {
        notify("This domain is already registered by another user! 🚫", "error");
      } else {
        notify(err.message || "Failed to link domain.", "error");
      }
    }
    setSaving(false);
  };

  const handleRemoveDomain = async () => {
    if (!window.confirm("Are you sure you want to remove your custom domain? 🗑️")) return;
    setSaving(true);
    try {
      await sb.saveDomain(user.id, null, user?.token);
      notify("Domain removed successfully!", "success");
      setDomain("");
      onClose();
    } catch (err) {
      notify("Failed to remove domain.", "error");
    }
    setSaving(false);
  };

  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.85)", backdropFilter: "blur(8px)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 100, padding: 20 }}>
      <div className="card" style={{ width: "100%", maxWidth: 500, padding: "30px", position: "relative", background: "#0c1024", border: "1px solid var(--bdr2)", borderRadius: 20, boxShadow: "0 20px 50px rgba(0,0,0,0.5)" }}>
        <button onClick={onClose} style={{ position: "absolute", top: 20, right: 20, background: "rgba(255,255,255,0.05)", border: "1px solid var(--bdr2)", color: "var(--mut)", cursor: "pointer", width: 32, height: 32, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center" }}><I n="x" s={16} /></button>
        <h2 style={{ fontFamily: "'Orbitron',sans-serif", fontSize: 24, fontWeight: 900, marginBottom: 10, color: "#fff", display: "flex", alignItems: "center", gap: 10 }}>
          <I n="rocket" s={24} c="#10b981"/> Publish to Domain
        </h2>
        <p style={{ color: "var(--mut2)", fontSize: 14, marginBottom: 25, lineHeight: 1.6 }}>Connect your own custom domain (e.g. <b>www.yourgym.com</b>) to make your website live instantly.</p>
        <div style={{ background: "rgba(34,211,238,0.05)", border: "1px solid rgba(34,211,238,0.2)", padding: 18, borderRadius: 12, marginBottom: 20 }}>
            <h4 style={{ color: "#22d3ee", fontSize: 12, fontWeight: 800, marginBottom: 10, letterSpacing: 1 }}>STEP 1: DNS SETUP</h4>
            <p style={{ color: "var(--mut2)", fontSize: 13, lineHeight: 1.6 }}>Go to your domain provider (Hostinger, GoDaddy, etc.) and add a <strong>CNAME</strong> record pointing to:</p>
            <div style={{ background: "#000", padding: "10px 14px", borderRadius: 8, color: "#fff", display: "inline-block", marginTop: 10, border: "1px solid #333", fontSize: 13, fontFamily: "monospace", letterSpacing: 0.5 }}>
              cname.vercel-dns.com
            </div>
        </div>
        <div style={{ marginBottom: 25 }}>
          <label style={{ display: "block", fontSize: 12, color: "var(--mut)", marginBottom: 8, fontWeight: 700, letterSpacing: 1 }}>STEP 2: ENTER DOMAIN</label>
          <input type="text" className="inp" placeholder="e.g. www.rakeshgym.com" value={domain} onChange={e => setDomain(e.target.value)} style={{ background: "#070c1a", fontSize: 15, padding: "14px", border: "1px solid var(--bdr)" }} />
        </div>
        <button className="b bp" style={{ width: "100%", background: "linear-gradient(135deg,#10b981,#059669)", fontSize: 15, padding: "14px", borderRadius: 12, fontWeight: 700, border: "none", color: "#fff", cursor: "pointer", marginBottom: 10 }} onClick={handleLinkDomain} disabled={saving}>
          {saving ? "Saving Domain..." : "Link Domain & Publish"}
        </button>
        <button onClick={handleRemoveDomain} disabled={saving} style={{ width: "100%", background: "transparent", border: "1px solid rgba(239,68,68,0.3)", color: "#ef4444", fontSize: 13, padding: "10px", borderRadius: 12, cursor: "pointer", fontWeight: 600 }}>
          Remove Current Domain
        </button>
      </div>
    </div>
  );
};

// 🚨 SETTINGS MODAL WITH SUBSCRIPTION BADGE 🚨
const SettingsModal = ({ user, profile, onClose, notify }) => {
  const [apiKey, setApiKey] = useState(() => localStorage.getItem("dev_studio_custom_key") || "");
  const save = () => {
    if(apiKey.trim()) localStorage.setItem("dev_studio_custom_key", apiKey.trim());
    else localStorage.removeItem("dev_studio_custom_key");
    notify("Preferences saved securely! 🔒", "success"); onClose();
  };
  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.85)", backdropFilter: "blur(8px)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 100, padding: 20 }}>
      <div className="card" style={{ width: "100%", maxWidth: 480, padding: "32px", position: "relative", background: "#0c1024", border: "1px solid var(--bdr2)", borderRadius: 24, boxShadow: "0 25px 50px -12px rgba(0,0,0,0.7)" }}>
        <button onClick={onClose} style={{ position: "absolute", top: 20, right: 20, background: "rgba(255,255,255,0.05)", border: "1px solid var(--bdr2)", color: "var(--mut)", cursor: "pointer", width: 32, height: 32, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center" }}><I n="x" s={16} /></button>

        <div style={{display: "flex", alignItems: "center", gap: 14, marginBottom: 26}}>
           <div style={{width: 48, height: 48, borderRadius: 14, background: "linear-gradient(135deg, rgba(99,102,241,0.2), rgba(244,114,182,0.2))", display: "flex", alignItems: "center", justifyContent: "center", border: "1px solid rgba(99,102,241,0.3)"}}>
             <I n="user" s={22} c="#a5b4fc" />
           </div>
           <div>
             <h2 style={{ fontFamily: "'Orbitron',sans-serif", fontSize: 22, fontWeight: 800, color: "#fff", margin: 0 }}>Account Settings</h2>
             <p style={{color: "var(--mut2)", fontSize: 13, margin: "4px 0 0 0"}}>Manage your profile & developer keys.</p>
           </div>
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 16, marginBottom: 28 }}>
          
          {/* 🚨 SMART SUBSCRIPTION BADGE 🚨 */}
          <div style={{ padding: 18, background: profile.plan === 'free' ? "rgba(255,255,255,0.02)" : "rgba(34,211,238,0.05)", border: profile.plan === 'free' ? "1px solid var(--bdr2)" : "1px solid rgba(34,211,238,0.2)", borderRadius: 16, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <div>
              <p style={{ fontSize: 11, color: "var(--mut)", fontWeight: 700, letterSpacing: 0.5, marginBottom: 4 }}>CURRENT SUBSCRIPTION</p>
              <p style={{ fontSize: 18, color: "#fff", fontWeight: 800, fontFamily: "'Orbitron',sans-serif", textTransform: "capitalize" }}>{profile.plan === 'free' ? 'Free Tier' : profile.plan.replace('_', ' ')}</p>
              {profile.plan !== 'free' && profile.plan !== 'starter' && profile.plan_expiry && (
                 <p style={{fontSize: 11, color: "var(--mut2)", marginTop: 6}}>Valid till: {new Date(profile.plan_expiry).toLocaleDateString('en-IN')}</p>
              )}
              {profile.plan === 'starter' && (
                 <p style={{fontSize: 11, color: "var(--mut2)", marginTop: 6}}>Lifetime Access (1 Build)</p>
              )}
            </div>
            {profile.plan !== 'free' && <div style={{ background: "rgba(16,185,129,0.15)", color: "#10b981", fontSize: 11, fontWeight: 800, padding: "4px 10px", borderRadius: 8 }}>ACTIVE ✅</div>}
          </div>

          <div style={{display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16}}>
             <div>
                <label style={{ display: "block", fontSize: 11, color: "var(--mut)", marginBottom: 6, fontWeight: 700, letterSpacing: 0.5 }}>FULL NAME</label>
                <input type="text" className="inp" value={user?.name || "Guest"} disabled style={{background: "rgba(0,0,0,0.2)", color: "var(--mut2)", cursor: "not-allowed", border: "1px solid rgba(255,255,255,0.05)"}} />
             </div>
             <div>
                <label style={{ display: "block", fontSize: 11, color: "var(--mut)", marginBottom: 6, fontWeight: 700, letterSpacing: 0.5 }}>EMAIL ADDRESS</label>
                <input type="text" className="inp" value={user?.email || "-"} disabled style={{background: "rgba(0,0,0,0.2)", color: "var(--mut2)", cursor: "not-allowed", border: "1px solid rgba(255,255,255,0.05)"}} />
             </div>
          </div>

          <div style={{ height: 1, background: "var(--bdr2)", margin: "8px 0" }}></div>

          <div style={{ padding: 22, background: "rgba(168,85,247,0.05)", border: apiKey ? "1px solid #d946ef" : "1px solid rgba(168,85,247,0.2)", borderRadius: 16, position: "relative", overflow: "hidden", transition: "0.3s" }}>
            <div style={{position: "absolute", top: 0, left: 0, width: 4, bottom: 0, background: "linear-gradient(180deg, #a855f7, #d946ef)"}}></div>
            <div style={{ display: "flex", gap: 10, marginBottom: 8, alignItems: "center" }}>
               <I n="key" s={18} c="#d946ef" />
               <label style={{ fontSize: 15, color: "#fff", fontWeight: 700, fontFamily: "'Orbitron',sans-serif", letterSpacing: 0.5 }}>Bring Your Own Key (BYOK)</label>
            </div>
            <p style={{color: "var(--mut2)", fontSize: 13, lineHeight: 1.5, marginBottom: 18}}>
               Bypass generation limits instantly. Enter your own <b>Claude</b> or <b>OpenAI</b> API key below. <br/>
               <span style={{display: "inline-flex", alignItems: "center", gap: 5, color: "#10b981", marginTop: 10, fontSize: 12, fontWeight: 600, background: "rgba(16,185,129,0.1)", padding: "4px 10px", borderRadius: 8}}>
                 <I n="shield" s={12} c="#10b981" /> Stored securely in your browser.
               </span>
            </p>
            <div style={{position: "relative"}}>
               <input type="password" className="inp" placeholder="e.g. sk-ant-api03-..." value={apiKey} onChange={e => setApiKey(e.target.value)} style={{ background: "#050812", paddingLeft: 42, borderColor: apiKey ? "rgba(217,70,239,0.4)" : "var(--bdr)", boxShadow: apiKey ? "inset 0 2px 8px rgba(0,0,0,0.4), 0 0 0 2px rgba(217,70,239,0.1)" : "inset 0 2px 8px rgba(0,0,0,0.4)" }} />
               <div style={{position: "absolute", left: 14, top: "50%", transform: "translateY(-50%)", color: apiKey ? "#d946ef" : "var(--mut)"}}>
                 <I n="lock" s={16} />
               </div>
            </div>
          </div>

        </div>
        <button className="b" style={{ width: "100%", background: "linear-gradient(135deg, #8b5cf6, #d946ef)", color: "#fff", border: "none", padding: "16px", borderRadius: 14, fontWeight: 800, fontSize: 15, cursor: "pointer", boxShadow: "0 8px 20px rgba(217,70,239,0.25)" }} onClick={save}>
          Save Preferences
        </button>
      </div>
    </div>
  );
};

const SubModal = ({ user, onClose, onSuccess, notify, mode }) => {
  const [loading, setLoading] = useState(false);
  const [isYearly, setIsYearly] = useState(false);

  const pay = async (amount, planId, planName) => {
    setLoading(true);
    await openPhonePe({ 
      amount, 
      planId, 
      planName, 
      user,
      onError: (err) => { notify(err, "error"); setLoading(false); }
    });
  };

  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.85)", backdropFilter: "blur(8px)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 100, padding: 20 }}>
      <div className="card" style={{ width: "100%", maxWidth: mode === "proOnly" ? 400 : 850, padding: "35px 25px", position: "relative", background: "#0c1024", border: "1px solid var(--bdr2)", borderRadius: 24, maxHeight: "90vh", overflowY: "auto" }}>
        <button onClick={onClose} style={{ position: "absolute", top: 20, right: 20, background: "rgba(255,255,255,0.05)", border: "1px solid var(--bdr2)", color: "var(--mut)", cursor: "pointer", width: 32, height: 32, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center" }}><I n="x" s={16} /></button>
        <div style={{ textAlign: "center", marginBottom: 30 }}>
          <span className="badge" style={{background:"rgba(245,158,11,0.08)",color:"#f59e0b",border:"1px solid rgba(245,158,11,0.2)",marginBottom:12, padding: "6px 14px", letterSpacing: 1, fontSize: 11}}>
            {mode === "proOnly" ? "PREMIUM FEATURE" : "UPGRADE NOW"}
          </span>
          <h2 style={{ fontFamily: "'Orbitron',sans-serif", fontSize: 26, fontWeight: 900, color: "#fff", marginBottom: 20 }}>
            {mode === "proOnly" ? "Get Pro for Custom Domains" : "Unlock Limitless AI"}
          </h2>
          <div style={{display:"flex",justifyContent:"center",alignItems:"center",gap:12}}>
            <span style={{color: !isYearly ? "#fff" : "var(--mut2)", fontWeight: 700, fontSize: 13, cursor: "pointer"}} onClick={() => setIsYearly(false)}>Monthly</span>
            <div onClick={() => setIsYearly(!isYearly)} style={{width: 46, height: 24, background: isYearly ? "linear-gradient(135deg,#10b981,#059669)" : "var(--bdr2)", borderRadius: 30, position: "relative", cursor: "pointer", transition: "0.3s"}}>
              <div style={{position: "absolute", top: 2, left: isYearly ? 24 : 2, width: 20, height: 20, background: "#fff", borderRadius: "50%", transition: "0.3s", boxShadow: "0 2px 5px rgba(0,0,0,0.2)"}}></div>
            </div>
            <span style={{color: isYearly ? "#fff" : "var(--mut2)", fontWeight: 700, fontSize: 13, cursor: "pointer", display: "flex", alignItems: "center", gap: 6}} onClick={() => setIsYearly(true)}>
              Yearly <span style={{background: "rgba(16,185,129,0.15)", color: "#10b981", fontSize: 9, padding: "2px 6px", borderRadius: 10, fontWeight: 800}}>SAVE 16%</span>
            </span>
          </div>
        </div>
        
        <div style={{ display: "grid", gridTemplateColumns: mode === "proOnly" ? "1fr" : "repeat(auto-fit, minmax(240px, 1fr))", gap: 20 }}>
          
          {mode !== "proOnly" && (
            <div style={{ background: "rgba(255,255,255,0.02)", border: "1px solid var(--bdr2)", borderRadius: 20, padding: 24, display: "flex", flexDirection: "column" }}>
              <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:15}}><div style={{width:38,height:38,borderRadius:10,background:"#94a3b816",display:"flex",alignItems:"center",justifyContent:"center"}}><I n="sparkle" s={18} c="#94a3b8"/></div><div style={{fontFamily:"'Orbitron',sans-serif",fontSize:18,fontWeight:900, color: "#fff"}}>Starter</div></div>
              <div style={{marginBottom:25}}><span style={{fontSize:36,fontWeight:800,fontFamily:"'Orbitron',sans-serif",color:"#cbd5e1"}}>₹9</span><span style={{color:"var(--mut)",fontSize:13}}>/once</span></div>
              <div style={{display:"flex",flexDirection:"column",gap:12,marginBottom:30, flex: 1}}>{["1 Premium AI Build", "Live Preview & Edit", "Clean HTML Export", "No Subscription"].map(f => ( <div key={f} style={{display:"flex",alignItems:"center",gap:10,fontSize:13}}><div style={{background:"#94a3b822", borderRadius:20, padding:2, display:"flex"}}><I n="check" s={10} c="#94a3b8"/></div><span style={{color:"var(--mut2)"}}>{f}</span></div> ))}</div>
              <button className="b" style={{width:"100%",background:"#334155",color:"#fff", border:"none", padding: "12px", borderRadius: 12, fontWeight: 700}} onClick={() => pay(9, "starter", "Starter Plan")} disabled={loading}>{loading ? "Wait..." : "Pay ₹9"}</button>
            </div>
          )}

          {mode !== "proOnly" && (
            <div style={{ background: "var(--surf)", border: "1px solid var(--bdr2)", borderRadius: 20, padding: 24, display: "flex", flexDirection: "column" }}>
              <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:15}}><div style={{width:38,height:38,borderRadius:10,background:"#6366f116",display:"flex",alignItems:"center",justifyContent:"center"}}><I n="zap" s={18} c="#6366f1"/></div><div style={{fontFamily:"'Orbitron',sans-serif",fontSize:18,fontWeight:900, color: "#fff"}}>Basic</div></div>
              <div style={{marginBottom:25}}><span style={{fontSize:36,fontWeight:800,fontFamily:"'Orbitron',sans-serif",color:"#6366f1"}}>{isYearly ? "₹1990" : "₹199"}</span><span style={{color:"var(--mut)",fontSize:13}}>{isYearly ? "/yr" : "/mo"}</span></div>
              <div style={{display:"flex",flexDirection:"column",gap:12,marginBottom:30, flex: 1}}>{["10 AI Builds / month", "3 Active Cloud Projects", "Standard HTML Export", "Email Support"].map(f => ( <div key={f} style={{display:"flex",alignItems:"center",gap:10,fontSize:13}}><div style={{background:"#6366f122", borderRadius:20, padding:2, display:"flex"}}><I n="check" s={10} c="#6366f1"/></div><span style={{color:"var(--mut2)"}}>{f}</span></div> ))}</div>
              <button className="b" style={{width:"100%",background:"linear-gradient(135deg,#6366f1,#8b5cf6)",color:"#fff", border:"none", padding: "12px", borderRadius: 12, fontWeight: 700}} onClick={() => pay(isYearly ? 1990 : 199, isYearly ? "basic_yearly" : "basic", isYearly ? "Basic Yearly" : "Basic")} disabled={loading}>{loading ? "Wait..." : "Upgrade to Basic"}</button>
            </div>
          )}

          <div style={{ background: "rgba(34,211,238,0.05)", border: "1px solid #22d3ee", borderRadius: 20, padding: 24, display: "flex", flexDirection: "column", position: "relative", overflow: "hidden" }}>
            <div style={{position:"absolute", top:0, left:0, right:0, height:4, background:"linear-gradient(90deg, #0ea5e9, #22d3ee)"}}></div>
            <div style={{position:"absolute", top:15, right:15, background:"linear-gradient(135deg, #0ea5e9, #22d3ee)", color:"#fff", fontSize:10, fontWeight:800, padding:"4px 10px", borderRadius:20}}>POPULAR</div>
            <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:15}}><div style={{width:38,height:38,borderRadius:10,background:"#22d3ee16",display:"flex",alignItems:"center",justifyContent:"center"}}><I n="crown" s={18} c="#22d3ee"/></div><div style={{fontFamily:"'Orbitron',sans-serif",fontSize:18,fontWeight:900, color: "#fff"}}>Pro</div></div>
            <div style={{marginBottom:25}}><span style={{fontSize:36,fontWeight:800,fontFamily:"'Orbitron',sans-serif",color:"#22d3ee"}}>{isYearly ? "₹4990" : "₹499"}</span><span style={{color:"var(--mut)",fontSize:13}}>{isYearly ? "/yr" : "/mo"}</span></div>
            <div style={{display:"flex",flexDirection:"column",gap:12,marginBottom:30, flex: 1}}>{["Unlimited AI Builds", "Unlimited Cloud Projects", "Priority Fast Generation", "Custom Domain Support ✨"].map(f => ( <div key={f} style={{display:"flex",alignItems:"center",gap:10,fontSize:13}}><div style={{background:"#22d3ee22", borderRadius:20, padding:2, display:"flex"}}><I n="check" s={10} c="#22d3ee"/></div><span style={{color: "white", fontWeight: f.includes("Domain") ? 700 : 400}}>{f}</span></div> ))}</div>
            <button className="b" style={{width:"100%",background:"linear-gradient(135deg,#0ea5e9,#22d3ee)",color:"#fff", border:"none", padding: "12px", borderRadius: 12, fontWeight: 700}} onClick={() => pay(isYearly ? 4990 : 499, isYearly ? "pro_yearly" : "pro", isYearly ? "Pro Yearly" : "Pro")} disabled={loading}>{loading ? "Wait..." : "Upgrade to Pro"}</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default function Dashboard({ user, onLogout, notify, onBack, openUpgrade, onUpgradeClosed }) {
  const localKey = `dev_studio_local_${user?.email || "guest"}`;
  const [prompt, setPrompt] = useState("");
  const [loading, setLoading] = useState(false);
  const [cloudSyncing, setCloudSyncing] = useState(true);
  const [tab, setTab] = useState("preview");
  const [previewMode, setPreviewMode] = useState("desktop"); 
  const [mobileTab, setMobileTab] = useState("chat"); 
  
  const [html, setHtml] = useState(() => localStorage.getItem(localKey + "_html") || "");
  const [messages, setMessages] = useState(() => JSON.parse(localStorage.getItem(localKey + "_msgs") || "[]"));
  
  const [showSub, setShowSub] = useState(false);
  const [subMode, setSubMode] = useState("all"); 
  const [showMenu, setShowMenu] = useState(false); 
  const [showSettings, setShowSettings] = useState(false);
  const [showPublish, setShowPublish] = useState(false);

  const [profile, setProfile] = useState({ plan: user?.plan || "free", cnt: user?.promptCount || 0, plan_expiry: null });
  const chatEndRef = useRef(null);

  // 🚨 NEW 1: PAYMENT SUCCESS - SET EXPIRY & SEND INVOICE 🚨
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const paymentStatus = urlParams.get('payment');
    
    if (paymentStatus === 'success') {
      const plan = urlParams.get('plan') || 'Premium';
      const amt = urlParams.get('amt') || '0';
      
      // ⏳ Calculate Plan Expiry Date
      let days = 30; // Basic/Pro (Monthly)
      if (plan.includes('yearly')) days = 365; // Yearly
      if (plan === 'starter') days = 36500; // Lifetime (1 Build)

      const expiryDate = new Date();
      expiryDate.setDate(expiryDate.getDate() + days);
      const expiryStr = expiryDate.toISOString();
      
      if (user?.token) {
        sb.updateProfile(user.id, { plan: plan, plan_expiry: expiryStr }, user.token).catch(()=>{});
      }
      setProfile(prev => ({ ...prev, plan: plan, plan_expiry: expiryStr }));
      notify(`Payment Successful! Upgraded to ${plan} 🎉`, "success");
      
      // 📧 Send Invoice Email
      try {
        fetch("/api/send-email", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email: user?.email, name: user?.name, planName: plan, amount: amt, emailType: "invoice" })
        });
      } catch (err) { console.log("Email error:", err); }

      window.history.replaceState({}, document.title, "/");
    } else if (paymentStatus === 'failed') {
      notify("Payment Failed! Please try again.", "error");
      window.history.replaceState({}, document.title, "/");
    } else if (paymentStatus === 'error') {
      notify("An error occurred during payment verification.", "error");
      window.history.replaceState({}, document.title, "/");
    }
  }, [user, notify]);

  // 🚨 NEW 2: SMART LOGIN CHECKER (AUTO EXPIRE & WARNING) 🚨
  useEffect(() => {
    if (!user?.id) { setCloudSyncing(false); return; }
    const fetchCloudData = async () => {
      try {
        const prof = await sb.getProfile(user.id, user.token);
        if (prof) {
          let currentPlan = prof.plan || 'free';
          let expiryStr = prof.plan_expiry;

          // Check Expiry if not free and not lifetime
          if (currentPlan !== 'free' && currentPlan !== 'starter' && expiryStr) {
             const expiryDate = new Date(expiryStr);
             const now = new Date();
             const diffDays = Math.ceil((expiryDate - now) / (1000 * 60 * 60 * 24));

             if (diffDays <= 0) {
               // ❌ PLAN EXPIRED! Remove Badge and Revert to Free
               currentPlan = 'free';
               expiryStr = null;
               await sb.updateProfile(user.id, { plan: 'free', plan_expiry: null }, user.token);
               notify("Your subscription has expired! Pro access removed.", "error");

               // 📧 Send Expired Email
               try {
                  fetch("/api/send-email", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ email: user?.email, name: user?.name, planName: prof.plan, emailType: "expired" })
                  });
               } catch(e) {}
             } 
             else if (diffDays <= 3) {
               // ⏳ WARNING (3 Days Left)
               notify(`⚠️ Your ${currentPlan} plan expires in ${diffDays} days!`, "warning");
               
               // To avoid sending 100 emails a day, check local storage
               const warnedKey = `dev_studio_warned_${user.id}_${diffDays}`;
               if (!localStorage.getItem(warnedKey)) {
                 localStorage.setItem(warnedKey, "true");
                 try {
                    fetch("/api/send-email", {
                      method: "POST",
                      headers: { "Content-Type": "application/json" },
                      body: JSON.stringify({ email: user?.email, name: user?.name, planName: currentPlan, daysLeft: diffDays, emailType: "warning" })
                    });
                 } catch(e) {}
               }
             }
          }
          setProfile({ plan: currentPlan, cnt: prof.prompt_count || 0, plan_expiry: expiryStr });
        }

        const cloudData = await sb.loadProject(user.id, user.token);
        if (cloudData && cloudData.html_code) {
          setHtml(cloudData.html_code);
          setMessages(cloudData.messages || []);
        }
      } catch (err) {} finally { setCloudSyncing(false); }
    };
    fetchCloudData();
  }, [user?.id, user?.token, notify]);

  // Handle Magic Prompt from Landing
  useEffect(() => {
    const savedPrompt = localStorage.getItem("dev_studio_magic_prompt");
    if (savedPrompt) {
      setPrompt(savedPrompt);
      localStorage.removeItem("dev_studio_magic_prompt");
      setTimeout(() => { build(savedPrompt); }, 500); 
    }
  }, []);

  useEffect(() => {
    localStorage.setItem(localKey + "_html", html);
    localStorage.setItem(localKey + "_msgs", JSON.stringify(messages));
  }, [html, messages, localKey]);

  useEffect(() => { chatEndRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages, loading]);
  useEffect(() => { if (openUpgrade) { setSubMode("all"); setShowSub(true); } }, [openUpgrade]);

  const loadTexts = html ? ["Updating design... 🎨", "Polishing code... ✨"] : ["Analyzing request... 🧠", "Injecting Tailwind CSS... 🎨", "Building layout... ✨", "Finalizing code... 🚀"];
  const [lti, setLti] = useState(0);
  useEffect(() => { let i; if(loading) { setLti(0); i = setInterval(() => setLti(p => (p + 1) % loadTexts.length), 2500); } return () => clearInterval(i); }, [loading, html]);

  const hasKey = !!localStorage.getItem("dev_studio_custom_key");
  const canBuild = profile.plan !== "free" || profile.cnt < 1 || hasKey;

  const starters = [
    { label: "☕ Coffee Shop", text: "Create a cozy coffee shop landing page." },
    { label: "💼 Portfolio", text: "Design a minimal personal portfolio." },
    { label: "🏋️ Gym Website", text: "Build a high-energy gym landing page." }
  ];

  const build = async (pOverride) => {
    const finalPrompt = pOverride || prompt;
    if (!finalPrompt.trim()) return;
    if (!canBuild) { setSubMode("all"); setShowSub(true); return; }
    
    setPrompt(""); 
    const newMsgs = [...messages, { role: "user", text: finalPrompt }];
    setMessages(newMsgs); 
    setLoading(true); 
    
    try {
      let finalApiPrompt = `Analyze the following user input: "${finalPrompt}". 
      RULE 1: If the user is just saying hi, thank you, or chatting normally, reply conversationally and MUST start your exact response with the text "CHAT: ". 
      RULE 2: If the user is asking to build or change a website, act as a world-class Frontend Engineer. RETURN ONLY RAW HTML CODE using Tailwind CSS CDN. MUST INCLUDE <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"> in <head>. Do NOT output markdown. Do NOT use the word CHAT.`;

      if (html && !finalPrompt.toLowerCase().includes("thank") && !finalPrompt.toLowerCase().includes("hi ")) {
        finalApiPrompt = `Update this HTML to fulfill: "${finalPrompt}". Maintain Tailwind CSS. RETURN ONLY FULL RAW HTML CODE. No markdown.\n\n${html}`;
      }

      const customKey = localStorage.getItem("dev_studio_custom_key") || "";
      const apiRes = await fetch("/api/generate", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-custom-key": customKey
        },
        body: JSON.stringify({ prompt: finalApiPrompt })
      });

      const data = await apiRes.json();
      if (!apiRes.ok) throw new Error(data.error || "Failed to generate website.");

      let g = data.content?.[0]?.text || "";
      if (!g) throw new Error("Invalid response from AI server.");

      g = g.trim();

      if (g.startsWith("CHAT:") || g.startsWith("CHAT: ")) {
        const chatReply = g.replace(/^CHAT:\s*/i, "");
        setMessages([...newMsgs, { role: "ai", text: chatReply }]);
        setLoading(false);
        return; 
      }

      let htmlCode = g.replace(/```html/g, "").replace(/```/g, "").trim();

      const guardScript = `
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
        <style> html { scroll-behavior: smooth; } </style>
        <script>
          document.addEventListener('click', function(e) {
            var a = e.target.closest('a');
            if (a) {
              e.preventDefault(); 
              e.stopPropagation();
              var href = a.getAttribute('href');
              if (href && href.startsWith('#') && href.length > 1) {
                try { document.querySelector(href).scrollIntoView({ behavior: 'smooth' }); } catch(err) {}
              }
            }
          }, true);
          document.addEventListener('submit', function(e) { e.preventDefault(); e.stopPropagation(); }, true);
        </script>
      `;

      htmlCode = htmlCode.replace(/<meta[^>]*name=["']viewport["'][^>]*>/gi, '');

      if (/<head[^>]*>/i.test(htmlCode)) {
          htmlCode = htmlCode.replace(/(<head[^>]*>)/i, `$1\n${guardScript}`);
      } else if (/<html[^>]*>/i.test(htmlCode)) {
          htmlCode = htmlCode.replace(/(<html[^>]*>)/i, `$1\n<head>\n${guardScript}\n</head>`);
      } else {
          htmlCode = `<!DOCTYPE html>\n<html lang="en">\n<head>\n${guardScript}\n<script src="https://cdn.tailwindcss.com"></script>\n</head>\n<body>\n${htmlCode}\n</body>\n</html>`;
      }

      const updatedMsgs = [...newMsgs, { role: "ai", text: html ? "Website updated! ✨" : "Generated successfully! 🎉", htmlSnapshot: htmlCode }];
      
      setHtml(htmlCode);
      setMessages(updatedMsgs);
      setTab("preview");
      setMobileTab("preview");
      
      if (user?.id) sb.saveProject(user.id, htmlCode, updatedMsgs, user.token).catch(()=>{});
      if (!hasKey) {
        const nc = profile.cnt + 1; setProfile(p => ({ ...p, cnt: nc }));
        if (user?.token) sb.updateProfile(user.id, { prompt_count: nc }, user.token).catch(()=>{});
      }
      notify(html ? "Website updated!" : "Website generated!", "success");

    } catch (e) { 
      notify(e.message || "Failed to generate.", "error"); 
      setMessages(p => [...p, { role: "ai", text: "Failed. Please try again.", error: true }]); 
    }
    setLoading(false);
  };

  const enhance = () => {
    if (!prompt.trim()) return notify("Type something first!", "warning");
    setPrompt(`Make this highly professional and visually stunning. Use modern typography and glassmorphism. ${prompt}`);
    notify("Enhanced! ✨", "success");
  };

  const startNew = () => { 
    if(window.confirm("Start a fresh project? This clears current progress. 🚀")) { 
      setHtml(""); setMessages([]); setPrompt(""); 
      localStorage.removeItem(localKey + "_html");
      localStorage.removeItem(localKey + "_msgs");
      if(user?.id) sb.saveProject(user.id, "", [], user.token).catch(()=>{});
    } 
  };

  const downloadReactZip = async () => {
    if (!html) return;
    try {
      const zip = new JSZip();

      const packageJson = `{
  "name": "dev-studio-react-app",
  "private": true,
  "version": "1.0.0",
  "type": "module",
  "scripts": { "dev": "vite", "build": "vite build", "preview": "vite preview" },
  "dependencies": { "react": "^18.2.0", "react-dom": "^18.2.0" },
  "devDependencies": { "@vitejs/plugin-react": "^4.2.1", "vite": "^5.2.0" }
}`;

      const viteConfig = `import { defineConfig } from 'vite'\nimport react from '@vitejs/plugin-react'\nexport default defineConfig({\n  plugins: [react()],\n})`;

      const indexHtml = `<!doctype html>\n<html lang="en">\n  <head>\n    <meta charset="UTF-8" />\n    <meta name="viewport" content="width=device-width, initial-scale=1.0" />\n    <script src="https://cdn.tailwindcss.com"></script>\n    <title>Dev Studio Built Website</title>\n  </head>\n  <body class="bg-gray-50">\n    <div id="root"></div>\n    <script type="module" src="/src/main.jsx"></script>\n  </body>\n</html>`;

      const mainJsx = `import React from 'react'\nimport ReactDOM from 'react-dom/client'\nimport App from './App.jsx'\n\nReactDOM.createRoot(document.getElementById('root')).render(\n  <React.StrictMode>\n    <App />\n  </React.StrictMode>,\n)`;

      const appJsx = `import React from 'react';\n\nexport default function App() {\n  return (\n    <div dangerouslySetInnerHTML={{ __html: \`${html.replace(/`/g, '\\`').replace(/\$/g, '\\$')}\` }} />\n  );\n}\n`;

      zip.file("package.json", packageJson);
      zip.file("vite.config.js", viteConfig);
      zip.file("index.html", indexHtml);
      zip.folder("src").file("main.jsx", mainJsx);
      zip.folder("src").file("App.jsx", appJsx);

      const content = await zip.generateAsync({ type: "blob" });
      saveAs(content, "dev-studio-react-app.zip");
      notify("React Project Downloaded Successfully! 📦", "success");
    } catch (e) {
      notify("Failed to create ZIP file.", "error");
    }
  };

  if (cloudSyncing) {
    return (
      <div style={{ height: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: "#070c1a", flexDirection: "column", color: "#fff" }}>
        <div className="ld" style={{ width: 24, height: 24, borderWidth: 3, borderColor: "#6366f1", borderTopColor: "transparent", marginBottom: 15 }} />
        <p style={{ fontFamily: "'Orbitron',sans-serif", color: "#a5b4fc" }}>Syncing Cloud Data ☁️</p>
      </div>
    );
  }

  return (
    <div className="app-container">
      <style>{`
        .app-container { height: 100vh; display: flex; flex-direction: column; overflow: hidden; background: #070c1a; }
        .main-layout { display: flex; flex-direction: row; flex: 1; overflow: hidden; }
        .side-panel { width: 380px; flex-shrink: 0; display: flex; flex-direction: column; background: var(--surf); border-right: 1px solid var(--bdr2); z-index: 10; }
        .view-panel { flex: 1; display: flex; flex-direction: column; overflow: hidden; background: #070c1a; position: relative; }
        
        .mobile-tabs { display: none; }
        
        @media (max-width: 768px) {
          .desktop-only { display: none !important; }
          .mobile-tabs { 
            display: flex; background: #0c1024; border-top: 1px solid rgba(255,255,255,0.06); 
            justify-content: space-around; z-index: 50; flex-shrink: 0; 
            padding: 8px 10px; padding-bottom: env(safe-area-inset-bottom, 10px); 
          }
          .mtab { 
            flex: 1; text-align: center; color: #64748b; font-size: 12px; font-weight: 700; 
            display: flex; flex-direction: column; align-items: center; gap: 5px; 
            border-radius: 12px; padding: 6px; transition: all 0.2s; cursor: pointer; 
          }
          .mtab.on { color: #22d3ee; }
          .mtab i { filter: drop-shadow(0 0 0 transparent); transition: all 0.2s; }
          .mtab.on i { filter: drop-shadow(0 0 10px rgba(34,211,238,0.5)); }
          
          .main-layout.show-chat .view-panel { display: none !important; }
          .main-layout.show-preview .side-panel { display: none !important; }
          .side-panel { width: 100%; border-right: none; height: 100%; }
          .view-panel { width: 100%; height: 100%; }
        }
      `}</style>

      {showSub && <SubModal user={user} mode={subMode} onClose={() => setShowSub(false)} onSuccess={p => { setProfile(prev => ({ ...prev, plan: p })); setShowSub(false); }} notify={notify} />}
      {showSettings && <SettingsModal user={user} profile={profile} onClose={() => setShowSettings(false)} notify={notify} />}
      {showPublish && <PublishModal user={user} onClose={() => setShowPublish(false)} notify={notify} />}
      
      <header style={{ background: "rgba(12,16,36,0.97)", backdropFilter: "blur(20px)", borderBottom: "1px solid var(--bdr2)", padding: "0 18px", height: 60, display: "flex", alignItems: "center", justifyContent: "space-between", flexShrink: 0, zIndex: 20 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 15 }}>
          {onBack && <button onClick={onBack} style={{ background: "transparent", border: "1px solid var(--bdr2)", color: "var(--mut)", fontSize: 12, padding: "5px 10px", borderRadius: 6, cursor: "pointer" }}>← Back</button>}
          <div style={{ display: "flex", alignItems: "center", gap: 9 }}>
            <div style={{ width: 32, height: 32, borderRadius: 9, background: "linear-gradient(135deg,#6366f1,#22d3ee)", display: "flex", alignItems: "center", justifyContent: "center" }}><I n="logo" s={16} c="#fff" /></div>
            <span style={{ fontFamily: "'Orbitron',sans-serif", fontSize: 14, fontWeight: 900, letterSpacing: 1 }}>Dev Studio</span>
          </div>
        </div>
        <div style={{ position: "relative" }}>
          
          <div onClick={() => setShowMenu(!showMenu)} style={{ display: "flex", alignItems: "center", gap: 10, padding: "5px 12px 5px 5px", background: "rgba(99,102,241,0.07)", border: "1px solid var(--bdr)", borderRadius: 12, cursor: "pointer" }}>
            <div style={{ width: 30, height: 30, borderRadius: 8, background: "linear-gradient(135deg,#6366f1,#f472b6)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13, fontWeight: 700, color: "#fff" }}>{user?.name?.[0]?.toUpperCase() || "U"}</div>
            <div className="desktop-only" style={{ display: "flex", flexDirection: "column", justifyContent: "center" }}>
              <span style={{ fontSize: 12, fontWeight: 600, color: "#fff", lineHeight: 1.2 }}>{user?.name || "User"}</span>
              <span style={{ fontSize: 9, color: "var(--ac2)", fontWeight: 800, textTransform: "uppercase", letterSpacing: 0.5 }}>{profile.plan === 'free' ? 'Free Plan' : profile.plan.replace('_', ' ')}</span>
            </div>
            <I n="code" s={14} c="var(--mut)" />
          </div>

          {showMenu && (
            <div className="card" style={{ position: "absolute", top: "120%", right: 0, width: 180, background: "#0c1024", border: "1px solid var(--bdr2)", borderRadius: 8, padding: 6, zIndex: 100, boxShadow: "0 10px 40px rgba(0,0,0,0.8)" }}>
              <div onClick={() => { setShowMenu(false); setSubMode("all"); setShowSub(true); }} style={{ padding: "8px 10px", cursor: "pointer", color: "#cbd5e1", fontSize: 13 }}>🚀 Upgrade Plan</div>
              <div onClick={() => { setShowMenu(false); setShowSettings(true); }} style={{ padding: "8px 10px", cursor: "pointer", color: "#cbd5e1", fontSize: 13 }}>⚙️ Profile Settings</div>
              <div style={{ height: 1, background: "var(--bdr2)", margin: "4px 0" }} />
              <div onClick={() => { setShowMenu(false); onLogout(); }} style={{ padding: "8px 10px", cursor: "pointer", color: "#ef4444", fontSize: 13, borderRadius: 6 }}>🚪 Sign Out</div>
            </div>
          )}
        </div>
      </header>

      <div className={`main-layout ${mobileTab === 'chat' ? 'show-chat' : 'show-preview'}`}>
        
        <div className="side-panel">
          <div style={{ padding: "14px 20px", borderBottom: "1px solid var(--bdr2)", display: "flex", justifyContent: "space-between", alignItems: "center", background: "rgba(0,0,0,0.15)" }}>
            <span style={{ fontSize: 11, fontWeight: 700, color: "var(--mut2)", letterSpacing: 1 }}>CURRENT PROJECT</span>
            {messages.length > 0 && <button onClick={startNew} style={{ background: "transparent", border: "none", color: "var(--mut)", fontSize: 11, cursor: "pointer" }}><I n="refresh" s={12} /> New</button>}
          </div>

          <div style={{ flex: 1, overflowY: "auto", padding: 20, display: "flex", flexDirection: "column", gap: 16 }}>
            {messages.length === 0 ? (
              <div style={{ margin: "auto", textAlign: "center", color: "var(--mut2)", padding: 20 }}>
                <I n="wand" s={32} c="#a5b4fc" style={{ marginBottom: 15 }} />
                <h3 style={{ fontSize: 16, color: "#fff", marginBottom: 8 }}>AI Developer Ready</h3>
                <p style={{ fontSize: 13 }}>Click a starter idea below or type your vision.</p>
              </div>
            ) : ( messages.map((m, i) => ( <div key={i} style={{ alignSelf: m.role === "user" ? "flex-end" : "flex-start", background: m.role === "user" ? "linear-gradient(135deg,#6366f1,#4f46e5)" : "var(--bg)", padding: "12px 16px", borderRadius: 16, fontSize: 13, maxWidth: "90%", border: m.role === "ai" ? "1px solid var(--bdr2)" : "none" }}>{m.text}</div> )) )}
            {loading && <div style={{ alignSelf: "flex-start", background: "var(--bg)", padding: "12px 16px", borderRadius: 16, border: "1px solid var(--bdr2)", fontSize: 13, display: "flex", gap: 10 }}><div className="ld" style={{ width: 14, height: 14, borderWidth: 2 }} /> {loadTexts[lti]}</div>}
            <div ref={chatEndRef} />
          </div>

          <div style={{ padding: "16px", borderTop: "1px solid var(--bdr2)", background: "rgba(0,0,0,0.2)" }}>
            <div style={{ display: "flex", gap: 8, overflowX: "auto", marginBottom: 12, paddingBottom: 5 }} className="hide-scrollbar">
              {starters.map((s, i) => ( <button key={i} onClick={() => build(s.text)} style={{ whiteSpace: "nowrap", background: "rgba(255,255,255,0.05)", border: "1px solid var(--bdr2)", color: "#94a3b8", padding: "6px 12px", borderRadius: 20, fontSize: 11, cursor: "pointer" }}>{s.label}</button> ))}
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
              <span style={{ fontSize: 10, color: "var(--mut2)", fontWeight: 700 }}>DESCRIBE VISION</span>
              <button onClick={enhance} style={{ background: "transparent", border: "none", color: "#f59e0b", fontSize: 11, cursor: "pointer", fontWeight: 700 }}>✨ Magic Enhance</button>
            </div>
            <textarea className="inp" style={{ minHeight: 80, resize: "none", fontSize: 13, marginBottom: 10 }} placeholder="e.g. A dark travel blog..." value={prompt} onChange={e => setPrompt(e.target.value)} onKeyDown={e => { if((e.ctrlKey || e.metaKey) && e.key === "Enter") build(); }} />
            <button className="b bp" style={{ width: "100%" }} onClick={() => build()} disabled={loading || !prompt.trim()}>{loading ? <I n="refresh" className="spin" s={14}/> : <I n="wand" s={14} />} {html ? "Update & Save" : "Generate & Save"}</button>
          </div>
        </div>

        <div className="view-panel">
          <div style={{ padding: "9px 16px", borderBottom: "1px solid var(--bdr2)", display: "flex", alignItems: "center", justifyContent: "space-between", background: "var(--surf)", zIndex: 10, flexWrap: "wrap", gap: 10 }}>
            <div style={{ display: "flex", gap: 10 }}>
              <div className="tbar desktop-only">
                <button className={`tab ${tab === "preview" ? "on" : ""}`} onClick={() => { setTab("preview"); setMobileTab("preview"); }}>Preview</button>
                <button className={`tab ${tab === "code" ? "on" : ""}`} onClick={() => { setTab("code"); setMobileTab("code"); }}>Code</button>
              </div>
              {tab === "preview" && (
                <div className="tbar desktop-only">
                  <button className={`tab ${previewMode === "desktop" ? "on" : ""}`} onClick={() => setPreviewMode("desktop")}><I n="desktop" s={14} /></button>
                  <button className={`tab ${previewMode === "mobile" ? "on" : ""}`} onClick={() => setPreviewMode("mobile")}><I n="mobile" s={14} /></button>
                </div>
              )}
            </div>
            
            {html && (
              <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                <button className="b bs" onClick={() => { if (profile.plan === "pro" || profile.plan === "cofounder") { setShowPublish(true); } else { notify("Custom Domain is a Pro feature! 🚀", "warning"); setSubMode("proOnly"); setShowSub(true); } }} style={{ background: "linear-gradient(135deg,#10b981,#059669)", color: "#fff", border: "none", borderRadius: 8, cursor: "pointer", fontWeight: 700, display: "flex", alignItems: "center", gap: 6 }}>
                   🚀 Publish
                </button>
                <button className="b bgh bs" onClick={() => { navigator.clipboard.writeText(html); notify("Copied!", "success"); }}>Copy Code</button>
                <button className="b bp bs" style={{ background: "#3b82f6" }} onClick={downloadReactZip}>
                  <I n="dl" s={14} /> Download React App (.zip)
                </button>
              </div>
            )}
          </div>
          
          <div style={{ position: "relative", flex: 1, width: "100%", height: "100%", background: tab === "code" ? "#0f172a" : "#e2e8f0" }}>
            {!html && !loading ? (
               <div style={{ position: "absolute", top: "50%", left: "50%", transform: "translate(-50%, -50%)", textAlign: "center", width: "100%" }}>
                 <div style={{ fontSize: 50, marginBottom: 15 }}>🚀</div>
                 <h2 style={{ fontFamily: "'Orbitron',sans-serif", color: "#6366f1", fontSize: 20 }}>Start Building</h2>
                 <p style={{ color: "var(--mut2)", fontSize: 13 }}>Type a prompt above.</p>
               </div>
            ) : tab === "preview" ? (
              <div style={{ position: "absolute", inset: 0, overflow: "auto", WebkitOverflowScrolling: "touch", display: "flex", alignItems: "center", justifyContent: "center", padding: previewMode === "mobile" ? "20px" : "0" }}>
                <iframe 
                  srcDoc={html} 
                  title="Preview" 
                  sandbox="allow-scripts allow-forms allow-same-origin allow-popups"
                  style={{ width: previewMode === "mobile" ? "375px" : "100%", height: previewMode === "mobile" ? "812px" : "100%", maxWidth: "100%", borderRadius: previewMode === "mobile" ? "30px" : "0px", border: previewMode === "mobile" ? "10px solid #1e293b" : "none", background: "#fff", display: "block" }} 
                />
              </div>
            ) : (
              <div style={{ position: "absolute", inset: 0, overflow: "auto", padding: 24, background: "#0f172a" }}>
                <pre style={{margin:0}}><code style={{ fontSize: 13, lineHeight: 1.6 }} dangerouslySetInnerHTML={{ __html: highlightHTML(html) }} /></pre>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="mobile-tabs">
         <div className={`mtab ${mobileTab === 'chat' ? 'on' : ''}`} onClick={() => setMobileTab('chat')}>
            <I n="wand" s={22} c={mobileTab === 'chat' ? '#22d3ee' : 'currentColor'} /> 
            <span>Chat</span>
         </div>
         <div className={`mtab ${mobileTab === 'preview' ? 'on' : ''}`} onClick={() => { setMobileTab('preview'); setTab('preview'); }}>
            <I n="eye" s={22} c={mobileTab === 'preview' ? '#22d3ee' : 'currentColor'} /> 
            <span>Preview</span>
         </div>
         <div className={`mtab ${mobileTab === 'code' ? 'on' : ''}`} onClick={() => { setMobileTab('code'); setTab('code'); }}>
            <I n="code" s={22} c={mobileTab === 'code' ? '#22d3ee' : 'currentColor'} /> 
            <span>Code</span>
         </div>
      </div>
    </div>
  );
}
