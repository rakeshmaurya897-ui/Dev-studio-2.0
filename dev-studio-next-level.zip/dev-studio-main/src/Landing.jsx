import React, { useState } from "react";
import { I } from "./ui";

export default function Landing({ onStart, user }) {
  const [faq, setFaq] = useState(null);
  const [isYearly, setIsYearly] = useState(false); 
  
  const [magicPrompt, setMagicPrompt] = useState("");

  const handleMagicStart = () => {
    if (!magicPrompt.trim()) return;
    localStorage.setItem("dev_studio_magic_prompt", magicPrompt);
    onStart("signup"); 
  };

  const feats=[
    {ic:"wand",cl:"#6366f1",t:"AI Generation",d:"Type any description and get a complete, production-ready website in seconds. No coding required."},
    {ic:"eye",cl:"#22d3ee",t:"Live Preview",d:"See your site render instantly — toggle between desktop and mobile views as it builds."},
    {ic:"code",cl:"#f472b6",t:"Clean Code Export",d:"Download structured HTML, CSS and JS. Host anywhere — Vercel, Netlify, GitHub Pages."},
    {ic:"rocket",cl:"#f59e0b",t:"Lightning Fast",d:"Powered by advanced AI. Your website goes from prompt to live preview in under 10 seconds."},
    {ic:"mobile",cl:"#10b981",t:"Always Responsive",d:"Every generated website is fully mobile-first and tested across all screen sizes automatically."},
    {ic:"shield",cl:"#a78bfa",t:"Secure & Private",d:"Your prompts and builds are private. We never share your work without your permission."},
  ];

  const faqs=[
    {q:"Do I need to know how to code?",a:"Not at all. Dev Studio is designed for everyone — designers, founders, marketers. Just describe your vision in plain English."},
    {q:"What types of websites can I build?",a:"Landing pages, portfolios, SaaS sites, e-commerce fronts, agency sites, blogs, restaurants — the AI adapts to any description."},
    {q:"Can I edit the generated code?",a:"Yes. You get clean, readable HTML/CSS/JS that you can modify in any editor or hand off to a developer."},
    {q:"How does the subscription work?",a:"You get your first website build for just ₹9. After that, Basic (₹199/mo) gives 10 builds. Pro (₹499/mo) is fully unlimited. Choose Yearly billing to get 2 months free!"},
    {q:"Can I cancel anytime?",a:"Yes. No lock-in, no cancellation fees. Cancel from your dashboard and your plan stays active until the billing period ends."},
  ];

  return(
    <div style={{minHeight:"100vh",background:"var(--bg)"}}>
      
      <style>{`
        .top-nav { padding: 0 60px; }
        .hero-pad { padding: 80px 40px; }
        .section-pad { padding: 100px 60px; }
        @media (max-width: 768px) {
          .top-nav { padding: 0 20px; }
          .hide-on-mobile { display: none !important; }
          .hero-pad { padding: 60px 20px; }
          .section-pad { padding: 60px 20px; }
        }
      `}</style>

      <nav className="top-nav" style={{position:"sticky",top:0,zIndex:100,background:"rgba(5,8,18,0.92)",backdropFilter:"blur(20px)",borderBottom:"1px solid var(--bdr2)",height:66,display:"flex",alignItems:"center",justifyContent:"space-between"}}>
        <div style={{display:"flex",alignItems:"center",gap:10}}>
          <div style={{width:34,height:34,borderRadius:10,background:"linear-gradient(135deg,#6366f1,#22d3ee)",display:"flex",alignItems:"center",justifyContent:"center"}}><I n="logo" s={17} c="#fff"/></div>
          <span style={{fontFamily:"'Orbitron',sans-serif",fontSize:16,fontWeight:900,letterSpacing:1}} className="sh">Dev Studio</span>
        </div>
        <div style={{display:"flex",alignItems:"center",gap:8}}>
          <div className="hide-on-mobile" style={{display:"flex", gap:8}}>
            {[["#features","Features"],["#pricing","Pricing"],["#faq","FAQ"]].map(([h,l])=>(
              <a key={l} href={h} style={{color:"var(--mut2)",fontSize:13,fontWeight:600,textDecoration:"none",padding:"6px 14px",borderRadius:8,transition:"color 0.2s"}}
                onMouseEnter={e=>e.currentTarget.style.color="#fff"} onMouseLeave={e=>e.currentTarget.style.color="var(--mut2)"}>{l}</a>
            ))}
          </div>
          {user ? (
            <button className="b bp bs" style={{marginLeft:8, background:"linear-gradient(135deg,#10b981,#059669)"}} onClick={()=>onStart("dashboard")}>Go to Dashboard 🚀</button>
          ) : (
            <>
              <button className="b bgh bs hide-on-mobile" onClick={()=>onStart("login")} style={{marginLeft:8}}>Log In</button>
              <button className="b bp bs" onClick={()=>onStart("signup")}>Get Started for ₹9</button>
            </>
          )}
        </div>
      </nav>

      <section className="gbg hero-pad" style={{minHeight:"92vh",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",textAlign:"center",position:"relative",overflow:"hidden"}}>
        <div style={{position:"absolute",top:"15%",left:"10%",width:500,height:500,borderRadius:"50%",background:"radial-gradient(circle,rgba(99,102,241,0.1),transparent 70%)",filter:"blur(60px)",pointerEvents:"none"}}/>
        <div style={{position:"absolute",bottom:"10%",right:"5%",width:600,height:600,borderRadius:"50%",background:"radial-gradient(circle,rgba(34,211,238,0.06),transparent 70%)",filter:"blur(60px)",pointerEvents:"none"}}/>
        {[0,1,2,3,4,5].map(i=>(
          <div key={i} style={{position:"absolute",width:5,height:5,borderRadius:"50%",background:["#6366f1","#22d3ee","#f472b6","#f59e0b","#a78bfa","#10b981"][i],top:`${15+i*12}%`,left:`${8+i*14}%`,opacity:0.4,animation:`float ${2.5+i*0.5}s ease-in-out infinite`,animationDelay:`${i*0.3}s`,boxShadow:`0 0 10px ${["#6366f1","#22d3ee","#f472b6","#f59e0b","#a78bfa","#10b981"][i]}`}}/>
        ))}
        
        <div style={{marginBottom:20}}>
          <span className="badge" style={{background:"rgba(99,102,241,0.1)",color:"#a5b4fc",border:"1px solid rgba(99,102,241,0.22)",fontSize:12,padding:"6px 16px"}}>
            <I n="sparkle" s={11} c="#f59e0b"/> Dev Studio AI · No Code Required
          </span>
        </div>
        
        <h1 style={{fontFamily:"'Orbitron',sans-serif",fontSize:"clamp(30px,5vw,66px)",fontWeight:900,lineHeight:1.1,marginBottom:24,maxWidth:900}}>
          Build Any Website<br/><span className="sh">With a Single Prompt</span>
        </h1>
        
        <p style={{color:"var(--mut2)",fontSize:"clamp(15px,2vw,18px)",maxWidth:560,lineHeight:1.8,marginBottom:40}}>
          Describe your vision in plain English. Dev Studio's AI generates a complete, beautiful, fully responsive website — ready to download and deploy instantly.
        </p>

        <div className="asu" style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.15)", borderRadius: 18, padding: 8, display: "flex", gap: 10, width: "100%", maxWidth: 650, margin: "0 auto 64px auto", boxShadow: "0 20px 40px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.1)" }}>
          <input
            type="text"
            placeholder="e.g. Build a dark mode portfolio for a Web Developer..."
            value={magicPrompt}
            onChange={e => setMagicPrompt(e.target.value)}
            onKeyDown={e => e.key === "Enter" && handleMagicStart()}
            style={{ flex: 1, background: "transparent", border: "none", color: "#fff", padding: "12px 20px", fontSize: 16, outline: "none", fontFamily: "'Syne', sans-serif" }}
          />
          <button onClick={handleMagicStart} className="b bp" style={{ padding: "0 28px", borderRadius: 12, fontSize: 15 }}>
            <I n="wand" s={18} /> Generate
          </button>
        </div>
      </section>

      <section id="features" className="section-pad" style={{maxWidth:1200,margin:"0 auto"}}>
        <div style={{textAlign:"center",marginBottom:64}}>
          <span className="badge" style={{background:"rgba(34,211,238,0.08)",color:"#22d3ee",border:"1px solid rgba(34,211,238,0.18)",marginBottom:16}}>FEATURES</span>
          <h2 style={{fontFamily:"'Orbitron',sans-serif",fontSize:"clamp(22px,3vw,40px)",fontWeight:900,marginBottom:14}}>Everything You Need</h2>
        </div>
        <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(300px,1fr))",gap:24}}>
          {feats.map(f=>(
            <div key={f.t} className="fc">
              <div style={{width:48,height:48,borderRadius:14,background:`${f.cl}16`,border:`1px solid ${f.cl}22`,display:"flex",alignItems:"center",justifyContent:"center",marginBottom:20}}>
                <I n={f.ic} s={22} c={f.cl}/>
              </div>
              <h3 style={{fontSize:17,fontWeight:700,marginBottom:10}}>{f.t}</h3>
              <p style={{color:"var(--mut2)",fontSize:14,lineHeight:1.7}}>{f.d}</p>
            </div>
          ))}
        </div>
      </section>

      <section id="pricing" className="section-pad">
        <div style={{maxWidth:920,margin:"0 auto"}}>
          <div style={{textAlign:"center",marginBottom:40}}>
            <span className="badge" style={{background:"rgba(245,158,11,0.08)",color:"#f59e0b",border:"1px solid rgba(245,158,11,0.2)",marginBottom:16}}>PRICING</span>
            <h2 style={{fontFamily:"'Orbitron',sans-serif",fontSize:"clamp(22px,3vw,40px)",fontWeight:900,marginBottom:14}}>Simple Pricing</h2>
          </div>

          <div style={{display:"flex",justifyContent:"center",alignItems:"center",gap:12,marginBottom:50}}>
            <span style={{color: !isYearly ? "#fff" : "var(--mut2)", fontWeight: 700, fontSize: 15, cursor: "pointer"}} onClick={() => setIsYearly(false)}>Monthly</span>
            <div onClick={() => setIsYearly(!isYearly)} style={{width: 54, height: 28, background: isYearly ? "linear-gradient(135deg,#10b981,#059669)" : "var(--bdr2)", borderRadius: 30, position: "relative", cursor: "pointer", transition: "0.3s"}}>
              <div style={{position: "absolute", top: 3, left: isYearly ? 29 : 3, width: 22, height: 22, background: "#fff", borderRadius: "50%", transition: "0.3s", boxShadow: "0 2px 5px rgba(0,0,0,0.2)"}}></div>
            </div>
            <span style={{color: isYearly ? "#fff" : "var(--mut2)", fontWeight: 700, fontSize: 15, cursor: "pointer", display: "flex", alignItems: "center", gap: 6}} onClick={() => setIsYearly(true)}>
              Yearly 
              <span style={{background: "rgba(16,185,129,0.15)", color: "#10b981", fontSize: 10, padding: "3px 8px", borderRadius: 12, fontWeight: 800, letterSpacing: 0.5}}>SAVE 16%</span>
            </span>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: 20 }}>
            {[
              {nm:"Starter",pr:"₹9",cl:"#64748b",ic:"sparkle",feats:["1 Website Build","Preview & Download","HTML Export"],cta:"Pay ₹9 & Start"},
              {nm:"Basic", pr: isYearly ? "₹1990" : "₹199", per: isYearly ? "/yr" : "/mo", cl:"#6366f1",ic:"zap",feats:["10 Builds / month","3 Active Projects","Email Support"],cta:"Get Basic"},
              {nm:"Pro", pr: isYearly ? "₹4990" : "₹499", per: isYearly ? "/yr" : "/mo", cl:"#22d3ee",ic:"crown",pop:true,feats:["Unlimited Builds","Unlimited Projects","Priority Support"],cta:"Get Pro"},
            ].map(p=>(
              <div key={p.nm} className={`pc ${p.pop?"pop":""}`} style={{cursor:"pointer"}} onClick={()=> {
                // 🚨 FIX: अब "Starter" पर क्लिक करने पर भी सीधा पेमेंट (Upgrade) पॉपअप खुलेगा
                if (user) { 
                  onStart("upgrade");
                } else { onStart("signup"); }
              }}>

                <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:18}}>
                  <div style={{width:38,height:38,borderRadius:10,background:`${p.cl}16`,display:"flex",alignItems:"center",justifyContent:"center"}}><I n={p.ic} s={17} c={p.cl}/></div>
                  <div style={{fontFamily:"'Orbitron',sans-serif",fontSize:15,fontWeight:900}}>{p.nm}</div>
                </div>
                <div style={{marginBottom:20}}>
                  <span style={{fontSize:28,fontWeight:800,fontFamily:"'Orbitron',sans-serif",color:p.cl}}>{p.pr}</span>
                  {p.per&&<span style={{color:"var(--mut)",fontSize:12}}>{p.per}</span>}
                </div>
                <div style={{display:"flex",flexDirection:"column",gap:8,marginBottom:22}}>
                  {p.feats.map(f=>(
                    <div key={f} style={{display:"flex",alignItems:"center",gap:7,fontSize:12}}>
                      <I n="check" s={11} c={p.cl}/><span style={{color:"var(--mut2)"}}>{f}</span>
                    </div>
                  ))}
                </div>
                <button className="b bs" style={{width:"100%",background:p.pop?"linear-gradient(135deg,#0ea5e9,#22d3ee)":"linear-gradient(135deg,#6366f1,#8b5cf6)",color:"#fff"}}>
                  {p.cta}
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="faq" className="section-pad" style={{background:"var(--surf)", borderTop:"1px solid var(--bdr2)"}}>
        <div style={{maxWidth:800, margin:"0 auto"}}>
          <div style={{textAlign:"center", marginBottom:50}}>
            <span className="badge" style={{background:"rgba(167,139,250,0.08)", color:"#a78bfa", border:"1px solid rgba(167,139,250,0.18)", marginBottom:16}}>FAQ</span>
            <h2 style={{fontFamily:"'Orbitron',sans-serif", fontSize:"clamp(22px,3vw,40px)", fontWeight:900}}>Frequently Asked Questions</h2>
          </div>
          <div style={{display:"flex", flexDirection:"column", gap:16}}>
            {faqs.map((f, i)=>(
              <div key={i} className="fc" style={{padding: "24px", cursor: "pointer", transition: "all 0.2s ease"}} onClick={() => setFaq(faq === i ? null : i)}>
                <div style={{display:"flex", justifyContent:"space-between", alignItems:"center", fontWeight:700, fontSize:16, color: faq === i ? "#fff" : "var(--txt)"}}>
                  {f.q}
                  <span style={{fontSize: 20, color: "var(--mut)", fontWeight: 400}}>{faq === i ? "−" : "+"}</span>
                </div>
                {faq === i && <div style={{marginTop:14, color:"var(--mut2)", fontSize:15, lineHeight:1.6, animation:"fadeIn 0.3s ease"}}>{f.a}</div>}
              </div>
            ))}
          </div>
        </div>
      </section>
      
    </div>
  );
}
