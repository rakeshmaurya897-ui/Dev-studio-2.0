import React, { useState } from "react";
import { I } from "./ui";
import { CONFIG, sb } from "./config";

export default function AuthPage({ initMode, onAuth, notify, onBack }) {
  const [mode, setMode] = useState(initMode || "login");
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [loading, setLoading] = useState(false);
  const [showPw, setShowPw] = useState(false);

  // इसे हमेशा true रखना है
  const isReady = true;

  const submit = async () => {
    if (!form.email || !form.password) {
      notify("Please fill in all fields", "error");
      return;
    }
    setLoading(true);
    try {
      if (mode === "signup") {
        const r = await sb.signUp(form.email, form.password, form.name || form.email.split("@")[0]);
        if (r.error) {
          notify(r.error.message || "Sign up failed", "error");
          setLoading(false);
          return;
        }
        notify("Account created! You can now log in.", "success");
        setMode("login");
      } else {
        const r = await sb.signIn(form.email, form.password);
        if (r.error || !r.access_token) {
          notify(r.error?.message || "Invalid email or password", "error");
          setLoading(false);
          return;
        }
        const prof = await sb.getProfile(r.user.id, r.access_token);
        onAuth({
          id: r.user.id,
          email: r.user.email,
          name: prof?.name || r.user.email.split("@")[0],
          token: r.access_token,
          plan: prof?.plan || "free",
          promptCount: prof?.prompt_count || 0
        });
      }
    } catch (e) {
      notify("An error occurred. Check credentials.", "error");
    }
    setLoading(false);
  };

  return (
    <div className="gbg" style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", padding: 20, position: "relative", overflow: "hidden" }}>
      <div style={{ position: "absolute", top: "15%", left: "5%", width: 400, height: 400, borderRadius: "50%", background: "radial-gradient(circle,rgba(99,102,241,0.1),transparent 70%)", filter: "blur(40px)", pointerEvents: "none" }} />
      <div style={{ position: "absolute", bottom: "10%", right: "8%", width: 500, height: 500, borderRadius: "50%", background: "radial-gradient(circle,rgba(34,211,238,0.06),transparent 70%)", filter: "blur(50px)", pointerEvents: "none" }} />

      <div className="card asu" style={{ width: "100%", maxWidth: 440, padding: "44px 38px", zIndex: 10 }}>
        <button onClick={onBack} style={{ background: "none", border: "none", color: "var(--mut)", cursor: "pointer", display: "flex", alignItems: "center", gap: 6, fontSize: 13, marginBottom: 26, padding: 0 }}>← Back to home</button>
        <div style={{ textAlign: "center", marginBottom: 30 }}>
          <div className="af" style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", width: 66, height: 66, borderRadius: 18, background: "linear-gradient(135deg,#6366f1,#22d3ee)", boxShadow: "0 8px 32px rgba(99,102,241,0.5)", marginBottom: 16 }}>
            <I n="logo" s={32} c="#fff" />
          </div>
          <h1 style={{ fontFamily: "'Orbitron',sans-serif", fontSize: 24, fontWeight: 900, letterSpacing: 2, marginBottom: 6 }} className="sh">Dev Studio</h1>
        </div>
        
        <div className="tbar" style={{ marginBottom: 26 }}>
          <button className={`tab ${mode === "login" ? "on" : ""}`} onClick={() => setMode("login")} style={{ flex: 1 }}>Log In</button>
          <button className={`tab ${mode === "signup" ? "on" : ""}`} onClick={() => setMode("signup")} style={{ flex: 1 }}>Sign Up</button>
        </div>
        
        <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          {mode === "signup" && (
            <div>
              <label style={{ fontSize: 11, color: "var(--mut)", fontWeight: 700, letterSpacing: 0.8, display: "block", marginBottom: 7 }}>FULL NAME</label>
              <div style={{ position: "relative" }}>
                <div style={{ position: "absolute", left: 14, top: "50%", transform: "translateY(-50%)", color: "var(--mut)" }}><I n="user" s={15} /></div>
                <input className="inp" style={{ paddingLeft: 43 }} placeholder="Your full name" value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} />
              </div>
            </div>
          )}
          <div>
            <label style={{ fontSize: 11, color: "var(--mut)", fontWeight: 700, letterSpacing: 0.8, display: "block", marginBottom: 7 }}>EMAIL ADDRESS</label>
            <div style={{ position: "relative" }}>
              <div style={{ position: "absolute", left: 14, top: "50%", transform: "translateY(-50%)", color: "var(--mut)" }}><I n="mail" s={15} /></div>
              <input className="inp" style={{ paddingLeft: 43 }} type="email" placeholder="you@example.com" value={form.email} onChange={e => setForm(p => ({ ...p, email: e.target.value }))} />
            </div>
          </div>
          <div>
            <label style={{ fontSize: 11, color: "var(--mut)", fontWeight: 700, letterSpacing: 0.8, display: "block", marginBottom: 7 }}>PASSWORD</label>
            <div style={{ position: "relative" }}>
              <div style={{ position: "absolute", left: 14, top: "50%", transform: "translateY(-50%)", color: "var(--mut)" }}><I n="lock" s={15} /></div>
              <input className="inp" style={{ paddingLeft: 43, paddingRight: 43 }} type={showPw ? "text" : "password"} placeholder="••••••••" value={form.password} onChange={e => setForm(p => ({ ...p, password: e.target.value }))} onKeyDown={e => e.key === "Enter" && submit()} />
              <button onClick={() => setShowPw(p => !p)} style={{ position: "absolute", right: 14, top: "50%", transform: "translateY(-50%)", background: "none", border: "none", color: "var(--mut)", cursor: "pointer" }}><I n="eye" s={15} /></button>
            </div>
          </div>
          <button className="b bp bl" style={{ width: "100%", marginTop: 4 }} onClick={submit} disabled={loading}>
            {loading ? <><div className="ld" style={{ width: 18, height: 18, borderWidth: 2 }} /> Please wait...</> : <><I n={mode === "login" ? "zap" : "rocket"} s={17} /> {mode === "login" ? "Sign In" : "Create Account"}</>}
          </button>
        </div>
      </div>
    </div>
  );
}
