import { Resend } from 'resend';
const resend = new Resend(process.env.RESEND_API_KEY);

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method Not Allowed' });

  const { email, name, planName, amount, emailType, daysLeft } = req.body;
  const date = new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' });

  try {
    let subject = "";
    let htmlContent = "";

    // ⏳ वॉर्निंग ईमेल (3 दिन बचे हैं)
    if (emailType === "warning") {
        subject = `⏳ Reminder: Dev Studio Plan expires in ${daysLeft} days!`;
        htmlContent = `
          <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto; border: 1px solid #eaeaea; border-radius: 12px; overflow: hidden;">
            <div style="background: #f59e0b; padding: 25px; text-align: center; color: white;">
              <h1 style="margin: 0; font-size: 24px;">Subscription Expiring Soon</h1>
            </div>
            <div style="padding: 30px; color: #334155; line-height: 1.6;">
              <p>Hello <b>${name || 'User'}</b>,</p>
              <p>Your Dev Studio <b>${planName}</b> plan will expire in just <b>${daysLeft} days</b>.</p>
              <p>Please renew your subscription to ensure your premium features keep working seamlessly.</p>
              <div style="text-align: center; margin-top: 30px;">
                <a href="https://devstudiobuild.in" style="background: #10b981; color: white; padding: 12px 24px; text-decoration: none; border-radius: 8px; font-weight: bold;">Renew Now</a>
              </div>
            </div>
          </div>
        `;
    } 
    // ❌ एक्सपायर ईमेल
    else if (emailType === "expired") {
        subject = `❌ Your Dev Studio Plan has Expired`;
        htmlContent = `
          <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto; border: 1px solid #eaeaea; border-radius: 12px; overflow: hidden;">
            <div style="background: #ef4444; padding: 25px; text-align: center; color: white;">
              <h1 style="margin: 0; font-size: 24px;">Subscription Expired</h1>
            </div>
            <div style="padding: 30px; color: #334155; line-height: 1.6;">
              <p>Hello <b>${name || 'User'}</b>,</p>
              <p>Your Dev Studio <b>${planName}</b> plan has officially expired. Your account has been reverted to the Free tier, and the Pro badge has been removed.</p>
              <p>Upgrade again to unlock unlimited AI builds!</p>
              <div style="text-align: center; margin-top: 30px;">
                <a href="https://devstudiobuild.in" style="background: #6366f1; color: white; padding: 12px 24px; text-decoration: none; border-radius: 8px; font-weight: bold;">Upgrade Now</a>
              </div>
            </div>
          </div>
        `;
    } 
    // ✅ सक्सेस इनवॉइस ईमेल
    else {
        subject = `Invoice & Welcome to Dev Studio ${planName} 🚀`;
        htmlContent = `
          <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto; border: 1px solid #eaeaea; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 10px rgba(0,0,0,0.05);">
            <div style="background: #050812; padding: 25px; text-align: center; color: white; border-bottom: 3px solid #6366f1;">
              <h1 style="margin: 0; font-size: 26px; font-weight: 800; letter-spacing: 1px;">Dev Studio</h1>
              <p style="margin: 5px 0 0; color: #94a3b8; font-size: 14px;">Payment Receipt & Invoice</p>
            </div>
            <div style="padding: 30px;">
              <p style="font-size: 16px; color: #334155;">Hello <b>${name || 'User'}</b>,</p>
              <p style="color: #475569; line-height: 1.6;">Thank you for your purchase! Your payment was successful, and your Dev Studio account has been upgraded instantly.</p>
              
              <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 20px; margin: 25px 0;">
                <h3 style="margin-top: 0; color: #0f172a; border-bottom: 1px solid #e2e8f0; padding-bottom: 12px; font-size: 15px; text-transform: uppercase;">Invoice Details</h3>
                <p style="margin: 10px 0; color: #475569; display: flex; justify-content: space-between;"><b>Date:</b> <span>${date}</span></p>
                <p style="margin: 10px 0; color: #475569; display: flex; justify-content: space-between;"><b>Plan Name:</b> <span style="text-transform: capitalize;">${planName}</span></p>
                <p style="margin: 10px 0; color: #475569; display: flex; justify-content: space-between;"><b>Amount Paid:</b> <span style="font-weight: bold; color: #0f172a;">₹${amount}</span></p>
                <div style="margin-top: 15px; padding-top: 15px; border-top: 1px dashed #cbd5e1; display: flex; justify-content: space-between; align-items: center;">
                  <b>Payment Status:</b> <span style="background: #10b981; color: white; padding: 4px 10px; border-radius: 20px; font-size: 12px; font-weight: bold;">PAID SUCCESS ✅</span>
                </div>
              </div>
              <div style="text-align: center; margin-bottom: 10px;">
                <a href="https://devstudiobuild.in" style="background: linear-gradient(135deg, #6366f1, #8b5cf6); color: white; padding: 14px 28px; text-decoration: none; border-radius: 8px; font-weight: bold; display: inline-block;">Go to Dashboard 🚀</a>
              </div>
            </div>
            <div style="background: #f1f5f9; padding: 15px; text-align: center; color: #64748b; font-size: 12px; border-top: 1px solid #e2e8f0;">
              <p style="margin: 0; font-weight: 600;">Dev Studio</p>
              <p style="margin: 4px 0 0;">Operated by Rakesh Kumar Maurya | Contact: support@devstudiobuild.in</p>
            </div>
          </div>
        `;
    }

    const data = await resend.emails.send({
      from: 'Dev Studio <onboarding@resend.dev>', // Vercel डोमेन वेरिफाई होने के बाद इसे बदल सकते हैं
      to: [email],
      subject: subject,
      html: htmlContent,
    });

    res.status(200).json(data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
}
