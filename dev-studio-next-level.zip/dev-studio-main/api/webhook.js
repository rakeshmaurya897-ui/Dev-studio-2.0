import crypto from 'crypto';

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).send('Method Not Allowed');

  try {
    // PhonePe यहाँ अपना सीक्रेट डेटा भेजता है
    const { response } = req.body;
    if (!response) return res.status(400).send("No payload");

    const saltKey = process.env.PHONEPE_SALT_KEY;
    const saltIndex = process.env.PHONEPE_SALT_INDEX || '1';

    // 1. सिक्योरिटी चेक (Verify Signature) - क्या यह सच में PhonePe से आया है?
    const xVerify = req.headers['x-verify'];
    const stringToHash = response + saltKey;
    const expectedSignature = crypto.createHash('sha256').update(stringToHash).digest('hex') + '###' + saltIndex;

    if (xVerify !== expectedSignature) {
      return res.status(400).send("Invalid Signature");
    }

    // 2. PhonePe को "OK" का सिग्नल वापस भेजना
    // (डेटाबेस अपडेट का काम हमारी phonepe-status.js पहले से कर रही है,
    // यह वेबहुक बस PhonePe के सर्वर को शांत करने के लिए है)
    
    res.status(200).send("OK");
  } catch (error) {
    res.status(500).send("Webhook Error");
  }
}
