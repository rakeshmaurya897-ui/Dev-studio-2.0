import React, { useEffect } from "react";

export const FontLoader = () => (
  <style>{`@import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Syne:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500;700&display=swap');`}</style>
);

export const GlobalStyles = () => (
  <style>{`
*{margin:0;padding:0;box-sizing:border-box}
html{scroll-behavior:smooth}
:root{
  --bg:#050812;--bg2:#071022;--surf:#0c1024;--surf2:#111827;--surf3:#0f172a;
  --bdr:rgba(99,102,241,0.2);--bdr2:rgba(255,255,255,0.06);--bdr3:rgba(148,163,184,0.16);
  --ac:#6366f1;--ac2:#22d3ee;--ac3:#f472b6;--gold:#f59e0b;--txt:#f1f5f9;--mut:#64748b;--mut2:#94a3b8;
  --ok:#10b981;--err:#ef4444;--shadow:0 24px 80px rgba(0,0,0,0.45);
}
body{
  background:
    radial-gradient(circle at top left, rgba(99,102,241,0.08), transparent 25%),
    radial-gradient(circle at top right, rgba(34,211,238,0.06), transparent 24%),
    linear-gradient(180deg, #040713 0%, #050812 32%, #04060d 100%);
  color:var(--txt);
  font-family:'Syne',sans-serif;
  overflow-x:hidden;
  min-height:100vh;
}
a{color:inherit}
button,input,textarea,select{font:inherit}
::selection{background:rgba(99,102,241,0.35);color:#fff}
::-webkit-scrollbar{width:6px;height:6px}
::-webkit-scrollbar-track{background:var(--surf)}
::-webkit-scrollbar-thumb{background:rgba(99,102,241,0.5);border-radius:999px}
:focus-visible{outline:2px solid rgba(34,211,238,0.8);outline-offset:2px}

.b{
  position:relative;display:inline-flex;align-items:center;justify-content:center;gap:8px;
  padding:12px 28px;border:none;border-radius:12px;font-family:'Syne',sans-serif;font-weight:700;
  font-size:14px;letter-spacing:0.5px;cursor:pointer;transition:all 0.18s cubic-bezier(0.34,1.56,0.64,1);
  text-transform:uppercase;outline:none;user-select:none;overflow:hidden;text-decoration:none;color:#fff;transform:translateZ(0)
}
.b::before{content:'';position:absolute;inset:0;border-radius:inherit;background:linear-gradient(180deg,rgba(255,255,255,0.16) 0%,transparent 65%);pointer-events:none}
.b::after{content:'';position:absolute;bottom:-4px;left:6px;right:6px;height:8px;border-radius:0 0 12px 12px;filter:blur(4px);opacity:0.75;transition:all 0.18s}
.b:hover{transform:translateY(-2px) scale(1.01)}.b:hover::after{bottom:-8px;opacity:1;height:12px}
.b:active{transform:translateY(1px) scale(0.985)}.b:active::after{bottom:-2px;height:4px}
.b:disabled{opacity:0.5;cursor:not-allowed;transform:none}

.bp{background:linear-gradient(135deg,#6366f1,#8b5cf6);box-shadow:0 6px 0 #3730a3,0 12px 28px rgba(99,102,241,0.34)}.bp::after{background:#3730a3}
.bc{background:linear-gradient(135deg,#0ea5e9,#22d3ee);box-shadow:0 6px 0 #0369a1,0 12px 28px rgba(34,211,238,0.3)}.bc::after{background:#0369a1}
.bg2{background:linear-gradient(135deg,#f59e0b,#fbbf24);color:#1c1917;box-shadow:0 6px 0 #b45309,0 12px 28px rgba(245,158,11,0.3)}.bg2::after{background:#b45309}
.bgh{background:rgba(99,102,241,0.08);color:#c7d2fe;border:1px solid rgba(99,102,241,0.25);box-shadow:0 4px 0 rgba(55,48,163,0.4),inset 0 1px 0 rgba(255,255,255,0.04)}.bgh::after{background:rgba(55,48,163,0.4)}.bgh:hover{background:rgba(99,102,241,0.15)}
.bs{padding:8px 18px;font-size:12px;border-radius:10px}.bl{padding:16px 40px;font-size:16px;border-radius:14px}.bxl{padding:20px 56px;font-size:18px;border-radius:16px}

.inp{
  background:rgba(15,23,42,0.82);border:1px solid var(--bdr);border-radius:14px;color:var(--txt);
  font-family:'Syne',sans-serif;font-size:15px;padding:14px 18px;width:100%;outline:none;
  transition:all 0.2s;box-shadow:inset 0 2px 10px rgba(0,0,0,0.32)
}
.inp:focus{border-color:var(--ac);box-shadow:inset 0 2px 10px rgba(0,0,0,0.32),0 0 0 3px rgba(99,102,241,0.18)}
.inp::placeholder{color:var(--mut)}
.card{background:linear-gradient(180deg,rgba(255,255,255,0.02),rgba(255,255,255,0.01)),var(--surf);border:1px solid var(--bdr2);border-radius:22px;box-shadow:var(--shadow),inset 0 1px 0 rgba(255,255,255,0.04)}
.gbg{background-image:linear-gradient(rgba(99,102,241,0.04) 1px,transparent 1px),linear-gradient(90deg,rgba(99,102,241,0.04) 1px,transparent 1px);background-size:40px 40px}
.glow{text-shadow:0 0 20px rgba(99,102,241,0.6),0 0 40px rgba(99,102,241,0.25)}
.badge{display:inline-flex;align-items:center;gap:6px;padding:4px 12px;border-radius:999px;font-size:11px;font-weight:700;letter-spacing:0.8px;text-transform:uppercase}
.sh{background:linear-gradient(90deg,#a5b4fc,#22d3ee,#f472b6,#a5b4fc);background-size:200% auto;-webkit-background-clip:text;-webkit-text-fill-color:transparent;animation:shimmer 3s linear infinite}

.main-layout{display:grid;grid-template-columns:minmax(320px,380px) minmax(0,1fr);min-height:calc(100vh - 66px);background:linear-gradient(180deg,rgba(255,255,255,0.02),transparent 12%)}
.side-panel,.view-panel{min-height:0;display:flex;flex-direction:column}
.side-panel{border-right:1px solid var(--bdr2);background:rgba(12,16,36,0.92);backdrop-filter:blur(18px)}
.view-panel{background:linear-gradient(180deg,rgba(255,255,255,0.035),transparent 18%),var(--surf)}
.desktop-only{display:block}
.hide-scrollbar{scrollbar-width:none;-ms-overflow-style:none}.hide-scrollbar::-webkit-scrollbar{display:none}

.tbar{display:flex;gap:4px;background:rgba(0,0,0,0.3);padding:6px;border-radius:14px;border:1px solid var(--bdr)}
.tab{padding:8px 20px;border-radius:10px;border:none;background:transparent;color:var(--mut);font-family:'Syne',sans-serif;font-weight:600;font-size:13px;cursor:pointer;transition:all 0.2s}
.tab.on{background:linear-gradient(135deg,var(--ac),#7c3aed);color:#fff;box-shadow:0 4px 12px rgba(99,102,241,0.35)}
.tab:hover:not(.on){color:var(--txt);background:rgba(99,102,241,0.1)}

.mo{position:fixed;inset:0;background:rgba(0,0,0,0.85);backdrop-filter:blur(8px);z-index:1000;display:flex;align-items:center;justify-content:center;padding:20px;animation:fadeIn 0.2s ease}
.mb{background:var(--surf);border:1px solid var(--bdr);border-radius:28px;max-width:860px;width:100%;max-height:90vh;overflow-y:auto;box-shadow:0 40px 100px rgba(0,0,0,0.6);animation:slideUp 0.3s cubic-bezier(0.34,1.56,0.64,1)}
.mb::-webkit-scrollbar{width:4px}.mb::-webkit-scrollbar-thumb{background:var(--ac);border-radius:2px}

.pc{background:var(--surf);border:1px solid var(--bdr2);border-radius:24px;padding:32px;position:relative;overflow:hidden;transition:all 0.3s cubic-bezier(0.34,1.56,0.64,1)}
.pc:hover{transform:translateY(-6px);box-shadow:0 20px 60px rgba(0,0,0,0.4)}
.pc.pop{border-color:var(--ac2);box-shadow:0 0 0 1px var(--ac2),0 8px 40px rgba(34,211,238,0.18)}
.pc::before{content:'';position:absolute;top:0;left:0;right:0;height:2px;background:linear-gradient(90deg,transparent,var(--ac),transparent)}
.pc.pop::before{background:linear-gradient(90deg,var(--ac2),var(--ac),var(--ac3))}

.fc{background:var(--surf);border:1px solid var(--bdr2);border-radius:20px;padding:28px;transition:all 0.3s;position:relative;overflow:hidden}
.fc::before{content:'';position:absolute;inset:0;border-radius:20px;background:radial-gradient(circle at 0% 0%,rgba(99,102,241,0.08),transparent 70%);opacity:0;transition:opacity 0.3s}
.fc:hover::before{opacity:1}.fc:hover{transform:translateY(-4px);border-color:rgba(99,102,241,0.3);box-shadow:0 12px 40px rgba(0,0,0,0.3)}

.toast{position:fixed;top:20px;right:20px;z-index:9999;background:var(--surf2);border:1px solid var(--bdr);border-radius:14px;padding:14px 20px;display:flex;align-items:center;gap:12px;box-shadow:0 12px 40px rgba(0,0,0,0.4);animation:slideUp 0.4s cubic-bezier(0.34,1.56,0.64,1);min-width:300px;font-size:14px}
.setup{background:linear-gradient(135deg,rgba(245,158,11,0.1),rgba(239,68,68,0.08));border:1px solid rgba(245,158,11,0.3);border-radius:14px;padding:16px 20px}

.mobile-tabs{display:none}
.mtab{display:flex;align-items:center;justify-content:center;gap:8px;min-height:54px;border-radius:16px;padding:10px 12px;border:1px solid transparent;color:var(--mut2);font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:0.6px;transition:all 0.2s;background:rgba(255,255,255,0.02)}
.mtab.on{background:linear-gradient(135deg,rgba(99,102,241,0.22),rgba(34,211,238,0.12));color:#fff;border-color:rgba(99,102,241,0.28);box-shadow:0 12px 28px rgba(99,102,241,0.12)}

@keyframes float{0%,100%{transform:translateY(0)}50%{transform:translateY(-12px)}}
@keyframes shimmer{0%{background-position:-200% center}100%{background-position:200% center}}
@keyframes slideUp{from{opacity:0;transform:translateY(30px)}to{opacity:1;transform:translateY(0)}}
@keyframes fadeIn{from{opacity:0}to{opacity:1}}
@keyframes spin{from{transform:rotate(0)}to{transform:rotate(360deg)}}
@keyframes prog{from{width:0}to{width:100%}}
@keyframes gs{0%{background-position:0% 50%}50%{background-position:100% 50%}100%{background-position:0% 50%}}
.af{animation:float 3s ease-in-out infinite}.asu{animation:slideUp 0.5s ease forwards}.afi{animation:fadeIn 0.4s ease forwards}.ga{background:linear-gradient(270deg,#6366f1,#22d3ee,#f472b6,#6366f1);background-size:400% 400%;animation:gs 8s ease infinite}.spin{animation:spin 0.8s linear infinite}.ld{width:40px;height:40px;border-radius:50%;border:3px solid rgba(99,102,241,0.2);border-top-color:var(--ac);animation:spin 0.8s linear infinite}.pb{height:3px;background:linear-gradient(90deg,var(--ac),var(--ac2));border-radius:999px;animation:prog 3s linear}

@media (max-width: 980px){
  .main-layout{grid-template-columns:1fr;min-height:calc(100vh - 66px);position:relative;overflow:hidden;padding-bottom:92px}
  .side-panel,.view-panel{display:none;position:absolute;inset:0;width:100%;height:100%;border-right:none}
  .main-layout.show-chat .side-panel{display:flex}
  .main-layout.show-preview .view-panel{display:flex}
  .desktop-only{display:none !important}
  .mobile-tabs{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;position:fixed;left:0;right:0;bottom:0;z-index:120;padding:10px 10px 12px;background:rgba(5,8,18,0.93);backdrop-filter:blur(18px);border-top:1px solid var(--bdr2)}
  .toast{left:12px;right:12px;top:auto;bottom:88px;min-width:0}
}

@media (max-width: 768px){
  .b{padding:11px 20px}.bl{padding:14px 28px}.bxl{padding:18px 34px}
  .pc,.fc{padding:24px;border-radius:20px}
  .card{border-radius:20px}
  .main-layout{min-height:calc(100vh - 66px)}
}

@media (prefers-reduced-motion: reduce){
  *,*::before,*::after{animation:none !important;scroll-behavior:auto !important;transition:none !important}
}
`}</style>
);

export const I = ({ n, s = 18, c = "currentColor" }) => {
  const m = {
    logo: <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2"><polygon points="12,2 22,8.5 22,15.5 12,22 2,15.5 2,8.5" /><polygon points="12,7 17,10 17,14 12,17 7,14 7,10" /></svg>,
    wand: <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2"><path d="M15 4V2" /><path d="M15 16v-2" /><path d="M8 9h2" /><path d="M20 9h2" /><path d="M17.8 11.8 19 13" /><path d="M15 9h.01" /><path d="M17.8 6.2 19 5" /><path d="m3 21 9-9" /><path d="M12.2 6.2 11 5" /></svg>,
    eye: <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z" /><circle cx="12" cy="12" r="3" /></svg>,
    code: <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2"><polyline points="16 18 22 12 16 6" /><polyline points="8 6 2 12 8 18" /></svg>,
    dl: <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" /><polyline points="7 10 12 15 17 10" /><line x1="12" y1="15" x2="12" y2="3" /></svg>,
    crown: <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2"><path d="m2 4 3 12h14l3-12-6 7-4-7-4 7-6-7zm3 16h14" /></svg>,
    check: <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2.5"><polyline points="20 6 9 17 4 12" /></svg>,
    x: <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" /></svg>,
    zap: <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2" /></svg>,
    user: <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" /><circle cx="12" cy="7" r="4" /></svg>,
    lock: <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2"><rect x="3" y="11" width="18" height="11" rx="2" /><path d="M7 11V7a5 5 0 0 1 10 0v4" /></svg>,
    mail: <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2"><rect x="2" y="4" width="20" height="16" rx="2" /><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7" /></svg>,
    rocket: <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2"><path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z" /><path d="m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z" /></svg>,
    sparkle: <svg width={s} height={s} viewBox="0 0 24 24" fill={c} stroke="none"><path d="M12 0L13.5 9 22 10.5 13.5 12 12 21 10.5 12 2 10.5 10.5 9z" /></svg>,
    refresh: <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2"><path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8" /><path d="M21 3v5h-5" /><path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16" /><path d="M8 16H3v5" /></svg>,
    desktop: <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2"><rect x="2" y="3" width="20" height="14" rx="2" /><line x1="8" y1="21" x2="16" y2="21" /><line x1="12" y1="17" x2="12" y2="21" /></svg>,
    mobile: <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2"><rect x="5" y="2" width="14" height="20" rx="2" /><line x1="12" y1="18" x2="12.01" y2="18" /></svg>,
    layers: <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2"><polygon points="12 2 2 7 12 12 22 7 12 2" /><polyline points="2 17 12 22 22 17" /><polyline points="2 12 12 17 22 12" /></svg>,
    info: <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2"><circle cx="12" cy="12" r="10" /><line x1="12" y1="16" x2="12" y2="12" /><line x1="12" y1="8" x2="12.01" y2="8" /></svg>,
    copy: <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2"><rect x="9" y="9" width="13" height="13" rx="2" /><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" /></svg>,
    history: <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2"><path d="M3 3v5h5" /><path d="M3.05 13A9 9 0 1 0 6 5.3L3 8" /><path d="M12 7v5l4 2" /></svg>,
    logout: <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" /><polyline points="16 17 21 12 16 7" /><line x1="21" y1="12" x2="9" y2="12" /></svg>,
    shield: <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" /></svg>,
    globe: <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2"><circle cx="12" cy="12" r="10" /><line x1="2" y1="12" x2="22" y2="12" /><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" /></svg>,
    star: <svg width={s} height={s} viewBox="0 0 24 24" fill={c} stroke="none"><polygon points="12,2 15.09,8.26 22,9.27 17,14.14 18.18,21.02 12,17.77 5.82,21.02 7,14.14 2,9.27 8.91,8.26" /></svg>,
  };
  return <span style={{ display: "inline-flex", alignItems: "center" }}>{m[n] || null}</span>;
};

export const Toast = ({ msg, type, onClose }) => {
  const col = { success: "#10b981", error: "#ef4444", info: "#6366f1", warning: "#f59e0b" };
  const ico = { success: "check", error: "x", info: "info", warning: "zap" };
  useEffect(() => {
    const t = setTimeout(onClose, 4500);
    return () => clearTimeout(t);
  }, []);

  return (
    <div className="toast">
      <div style={{ width: 32, height: 32, borderRadius: 8, background: `${col[type]}20`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
        <I n={ico[type]} s={15} c={col[type]} />
      </div>
      <span style={{ flex: 1, lineHeight: 1.4 }}>{msg}</span>
      <button onClick={onClose} style={{ background: "none", border: "none", color: "var(--mut)", cursor: "pointer", padding: 4 }}><I n="x" s={14} /></button>
    </div>
  );
};
