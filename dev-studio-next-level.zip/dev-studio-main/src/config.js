export const CONFIG = {
  SUPABASE_URL: "https://hoxpbkatpybilssxqkuc.supabase.co",
  SUPABASE_ANON_KEY: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImhveHBia2F0cHliaWxzc3hxa3VjIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzQ1MTQ1NTgsImV4cCI6MjA5MDA5MDU1OH0.Yj7cj4itwWLWCD7rL9RA20X27GG2DSyB5TYXmXkiMuo",
  ANTHROPIC_KEY: import.meta.env.VITE_ANTHROPIC_KEY
};

export const sb = {
  // 🔐 Headers
  h: (token) => {
    const localToken = localStorage.getItem("dev_studio_token");
    return { 
      "Content-Type": "application/json", 
      "apikey": CONFIG.SUPABASE_ANON_KEY, 
      "Authorization": `Bearer ${token || localToken || CONFIG.SUPABASE_ANON_KEY}` 
    };
  },
  
  signUp: async (email, password, name) => {
    const res = await fetch(`${CONFIG.SUPABASE_URL}/auth/v1/signup`, {
      method: "POST", headers: sb.h(), body: JSON.stringify({ email, password, data: { name } }) 
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || data.error_description || data.msg || "Signup failed");
    return data;
  },
  
  signIn: async (email, password) => {
    const res = await fetch(`${CONFIG.SUPABASE_URL}/auth/v1/token?grant_type=password`, {
      method: "POST", headers: sb.h(), body: JSON.stringify({ email, password })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || data.error_description || data.msg || "Invalid login credentials");
    return data;
  },
  
  getProfile: async (userId, token) => {
    const res = await fetch(`${CONFIG.SUPABASE_URL}/rest/v1/profiles?id=eq.${userId}&select=*`, { headers: sb.h(token) });
    const data = await res.json(); 
    return Array.isArray(data) ? data[0] : data;
  },
  
  updateProfile: async (userId, updates, token) => {
    const res = await fetch(`${CONFIG.SUPABASE_URL}/rest/v1/profiles?id=eq.${userId}`, {
      method: "PATCH", headers: { ...sb.h(token), "Prefer": "return=representation" }, body: JSON.stringify(updates)
    });
    const data = await res.json(); 
    return data[0];
  },

  // ☁️ Save Project
  saveProject: async (userId, html, messages, token) => {
    const res = await fetch(`${CONFIG.SUPABASE_URL}/rest/v1/projects`, {
      method: "POST",
      headers: { ...sb.h(token), "Prefer": "resolution=merge-duplicates,return=representation" },
      body: JSON.stringify({
        user_id: userId,
        html_code: html,
        messages: messages,
        updated_at: new Date().toISOString()
      })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || data.error_description || "Failed to save to cloud");
    return data[0];
  },

  // ☁️ Load Cloud Project
  loadProject: async (userId, token) => {
    const res = await fetch(`${CONFIG.SUPABASE_URL}/rest/v1/projects?user_id=eq.${userId}&select=*`, { 
      method: "GET", headers: sb.h(token) 
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || data.error_description || "Failed to load from cloud");
    return Array.isArray(data) && data.length > 0 ? data[0] : null;
  },

  // 🌐 NEW & POWERFUL: Save Custom Domain (Surgical PATCH Update)
  saveDomain: async (userId, domain, token) => {
    const res = await fetch(`${CONFIG.SUPABASE_URL}/rest/v1/projects?user_id=eq.${userId}`, {
      method: "PATCH", // PATCH ensures existing HTML is NOT deleted
      headers: { ...sb.h(token), "Prefer": "return=representation" },
      body: JSON.stringify({
        custom_domain: domain,
        updated_at: new Date().toISOString()
      })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || data.error_description || "Failed to link domain to database.");
    return Array.isArray(data) && data.length > 0 ? data[0] : null;
  }
};

// 🚀 PHONEPE PAYMENT GATEWAY INTEGRATION
export const openPhonePe = async ({ amount, planId, planName, user, onError }) => {
  try {
    const res = await fetch("/api/phonepe", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ amount, planId, planName, user })
    });
    const data = await res.json();
    
    if (data.url) {
      window.location.href = data.url; // Redirects user to PhonePe Page
    } else {
      onError(data.error || "Failed to initiate payment");
    }
  } catch (err) {
    onError("Could not connect to PhonePe Server");
  }
};
