export default async function handler(req, res) {
  const transactionId = req.query.id;
  const planId = req.query.planId;
  const amount = req.query.amount;

  try {
    const clientId = process.env.PHONEPE_MERCHANT_ID;
    const clientSecret = process.env.PHONEPE_SALT_KEY;
    const clientVersion = process.env.PHONEPE_SALT_INDEX || '1';

    // 🚀 स्टेप 1: स्टेटस चेक करने के लिए फिर से Auth Token लेना
    const tokenParams = new URLSearchParams();
    tokenParams.append('client_id', clientId);
    tokenParams.append('client_secret', clientSecret);
    tokenParams.append('client_version', clientVersion);
    tokenParams.append('grant_type', 'client_credentials');

    const tokenRes = await fetch("https://api.phonepe.com/apis/identity-manager/v1/oauth/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: tokenParams.toString()
    });

    const tokenData = await tokenRes.json();
    if (!tokenData.access_token) {
       return res.redirect(302, '/?payment=error');
    }

    // 🚀 स्टेप 2: नए V2 स्टेटस API से पेमेंट कन्फर्म करना
    const statusUrl = `https://api.phonepe.com/apis/pg/checkout/v2/order/${transactionId}/status`;
    
    const statusRes = await fetch(statusUrl, {
      method: 'GET',
      headers: { 'Authorization': `O-Bearer ${tokenData.access_token}` }
    });

    const statusData = await statusRes.json();
    const state = statusData.state || (statusData.data && statusData.data.state);

    if (state === 'COMPLETED' || state === 'SUCCESS') {
      res.redirect(302, `/?payment=success&plan=${planId}&amt=${amount}`);
    } else {
      res.redirect(302, '/?payment=failed');
    }
  } catch (error) {
    res.redirect(302, '/?payment=error');
  }
}
