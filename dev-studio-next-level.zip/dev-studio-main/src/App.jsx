import React, { useState, useCallback, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { FontLoader, GlobalStyles, Toast, I } from "./ui";
import { sb } from "./config";
import AuthPage from "./AuthPage";
import Dashboard from "./Dashboard";
import Landing from "./Landing"; 

// ==========================================
// 🚀 1. NEW: DEDICATED LEGAL PAGES FOR RAZORPAY
// ==========================================
const LegalPageLayout = ({ title, children }) => (
  <div style={{ minHeight: '100vh', background: '#050812', color: '#f1f5f9', padding: '60px 20px', fontFamily: "'Syne', sans-serif" }}>
    <div style={{ maxWidth: 800, margin: '0 auto', background: '#0c1024', padding: '40px', borderRadius: '24px', border: '1px solid rgba(255,255,255,0.06)', boxShadow: '0 25px 50px -12px rgba(0,0,0,0.5)' }}>
      <div style={{ marginBottom: 30 }}>
        <Link to="/" style={{ color: 'var(--mut)', textDecoration: 'none', fontSize: 14, display: 'inline-flex', alignItems: 'center', gap: 6, fontWeight: 600 }}>
          <I n="x" s={14} /> Back to Home
        </Link>
      </div>
      <h1 style={{ fontFamily: "'Orbitron', sans-serif", fontSize: '32px', fontWeight: 800, marginBottom: '30px', color: 'var(--ac2)' }}>
        {title}
      </h1>
      <div style={{ fontSize: '15px', lineHeight: '1.8', color: 'var(--mut2)' }}>
        {children}
      </div>
    </div>
  </div>
);

const ContactPage = () => (
  <LegalPageLayout title="Contact Us">
    <p><strong style={{color: '#fff'}}>Business Name:</strong> Dev Studio</p>
    <p><strong style={{color: '#fff'}}>Managed by:</strong> Rakesh Kumar Maurya</p>
    <p><strong style={{color: '#fff'}}>Email id:</strong> support@devstudiobuild.in</p>
    <p><strong style={{color: '#fff'}}>Phone number:</strong> +91-8707358704</p>
    <p><strong style={{color: '#fff'}}>Operating Address:</strong> Gram Nonar, Post Tulsi Ashram, Nonar, Chandauli, Uttar Pradesh - 232108</p>
  </LegalPageLayout>
);

const PrivacyPage = () => (
  <LegalPageLayout title="Privacy Policy">
    <p><strong style={{color: '#fff'}}>1. Information We Collect</strong><br/>When you place an order or subscribe to our newsletter, we may collect details such as your name, email address, contact information, and payment details.</p><br/>
    <p><strong style={{color: '#fff'}}>2. How We Use Your Information</strong><br/>Your information is used to process orders, provide order updates, respond to inquiries, and improve your shopping experience with Dev Studio.</p><br/>
    <p><strong style={{color: '#fff'}}>3. Cookies</strong><br/>We use cookies to personalize content, analyze traffic, and enhance your browsing experience. You can manage or disable cookies through your browser settings if you prefer.</p><br/>
    <p><strong style={{color: '#fff'}}>4. Data Security</strong><br/>We take necessary security measures to protect your personal data against unauthorized access, misuse, or disclosure, both online and offline.</p><br/>
    <p><strong style={{color: '#fff'}}>5. Third-Party Services</strong><br/>To fulfill your orders, certain information may be shared with trusted third-party partners (such as payment gateways and shipping providers). These partners only receive the information needed to complete their specific service.</p><br/>
    <p><strong style={{color: '#fff'}}>6. Updates to This Policy</strong><br/>Dev Studio may update this Privacy Policy from time to time. Any changes will be posted here, and we recommend reviewing this page periodically.</p>
    <div style={{marginTop: '20px', paddingTop: '15px', borderTop: '1px solid var(--bdr2)', color: '#fff'}}>
      <p><strong>Managed by:</strong> Rakesh Kumar Maurya</p>
      <p><strong>Email id:</strong> support@devstudiobuild.in</p>
      <p><strong>Phone number:</strong> +91-8707358704</p>
    </div>
  </LegalPageLayout>
);

const TermsPage = () => (
  <LegalPageLayout title="Terms & Conditions">
    <p><strong style={{color: '#fff'}}>1. Acceptance of Terms</strong><br/>By accessing or using Dev Studio website, you acknowledge and agree to comply with these Terms and Conditions.</p><br/>
    <p><strong style={{color: '#fff'}}>2. User Responsibilities</strong><br/>You agree not to engage in any actions that may disrupt, damage, or interfere with the smooth functioning of the website or its services.</p><br/>
    <p><strong style={{color: '#fff'}}>3. Intellectual Property Rights</strong><br/>All content, graphics, and materials featured on this website are the property of Dev Studio and are protected under applicable intellectual property laws.</p><br/>
    <p><strong style={{color: '#fff'}}>4. Limitation of Liability</strong><br/>Dev Studio will not be held responsible for any indirect, incidental, special, or consequential damages that may arise from your use of or access to our website.</p><br/>
    <p><strong style={{color: '#fff'}}>5. Indemnification</strong><br/>By using this website, you agree to indemnify and hold Dev Studio harmless from any claims, losses, or damages arising out of your use of the website.</p>
  </LegalPageLayout>
);

const RefundPage = () => (
  <LegalPageLayout title="No Refund Policy">
    As per our company policy, once a service is purchased, it is non-refundable. No refunds will be issued under any circumstances for these offerings.
  </LegalPageLayout>
);

// ==========================================
// 🚀 2. COOKIE BANNER
// ==========================================
const CookieBanner = () => {
  const [show, setShow] = useState(false);
  useEffect(() => {
    if (!localStorage.getItem("cookies_accepted")) setShow(true);
  }, []);

  if (!show) return null;
  return (
    <div style={{ position: "fixed", bottom: 20, left: 20, right: 20, background: "rgba(15,23,42,0.95)", backdropFilter: "blur(10px)", border: "1px solid var(--ac)", padding: "16px 24px", borderRadius: 16, zIndex: 9999, display: "flex", justifyContent: "space-between", alignItems: "center", gap: 20, boxShadow: "0 10px 40px rgba(0,0,0,0.5)", flexWrap: "wrap", animation: "slideUp 0.5s ease" }}>
      <div style={{ color: "#cbd5e1", fontSize: 13, lineHeight: 1.6, flex: 1, minWidth: 250 }}>
        <b style={{ color: "#fff", fontSize: 14 }}><I n="shield" s={14} c="var(--ac)" /> We value your privacy</b><br/>
        We use cookies to enhance your experience, save preferences, and prevent system abuse. By continuing, you agree to our cookie policy.
      </div>
      <button className="b bp" onClick={() => { localStorage.setItem("cookies_accepted", "true"); setShow(false); }}>Accept & Continue</button>
    </div>
  );
};

// ==========================================
// 🚀 3. MAIN APP LOGIC & ROUTING
// ==========================================
export default function App() {
  const location = useLocation();

  const [user, setUser] = useState(() => {
    try {
      localStorage.removeItem("dev_studio_user");
      const stored = localStorage.getItem("dev_studio_session");
      if (stored) {
        const { data, expiry } = JSON.parse(stored);
        if (Date.now() > expiry) {
          localStorage.removeItem("dev_studio_session");
          localStorage.removeItem("dev_studio_token"); 
          return null; 
        }
        return data; 
      }
      return null;
    } catch (error) {
      return null;
    }
  });

  const [page, setPage] = useState(() => {
    if (user) return "dashboard"; 
    return "landing"; 
  });

  useEffect(() => {
    if (!user && page === "dashboard") {
      setPage("landing");
    }
  }, [user, page]);
  
  const [authMode, setAuthMode] = useState("signup");
  const [openUpgrade, setOpenUpgrade] = useState(false);
  const [toasts, setToasts] = useState([]);

  useEffect(() => {
    if (user) {
      const now = new Date();
      const tomorrow = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
      tomorrow.setHours(0, 0, 0, 0); 
      localStorage.setItem("dev_studio_session", JSON.stringify({ data: user, expiry: tomorrow.getTime() }));
      if (user.token) localStorage.setItem("dev_studio_token", user.token);
    } else {
      localStorage.removeItem("dev_studio_session");
      localStorage.removeItem("dev_studio_token");
    }
  }, [user]);

  const notify = useCallback((msg, type = "info") => {
    const id = Date.now() + Math.random();
    setToasts(t => [...t, { id, msg, type }]);
  }, []);

  const removeToast = id => setToasts(t => t.filter(x => x.id !== id));

  const handleLogout = () => {
    localStorage.clear(); 
    setUser(null);
    setPage("landing");
    window.location.href = "/"; 
  };

  // 🚀 ROUTE INTERCEPTOR: अगर URL में पॉलिसी पेज है, तो सिर्फ उसे दिखाओ
  if (location.pathname === '/contact-us') return <><GlobalStyles /><ContactPage /></>;
  if (location.pathname === '/privacy-policy') return <><GlobalStyles /><PrivacyPage /></>;
  if (location.pathname === '/terms-and-conditions') return <><GlobalStyles /><TermsPage /></>;
  if (location.pathname === '/refund-policy') return <><GlobalStyles /><RefundPage /></>;

  return (
    <>
      <FontLoader />
      <GlobalStyles />
      
      <div style={{ position: "fixed", top: 20, right: 20, zIndex: 99999, display: "flex", flexDirection: "column", gap: 8, pointerEvents: "none" }}>
        {toasts.map(t => (
          <div key={t.id} style={{ pointerEvents: "auto" }}>
            <Toast msg={t.msg} type={t.type} onClose={() => removeToast(t.id)} />
          </div>
        ))}
      </div>
      
      {page === "landing" && (
        <>
          <Landing 
            user={user} 
            onStart={(m) => { 
              if (user) { 
                setPage("dashboard"); 
                if (m !== "dashboard") setOpenUpgrade(true);
              } else { 
                setAuthMode(m); 
                setPage("auth"); 
              } 
            }} 
          />
          
          <footer style={{ background: '#050812', padding: '40px 20px', textAlign: 'center', borderTop: '1px solid var(--bdr2)' }}>
            <div style={{ maxWidth: '800px', margin: '0 auto 30px auto', color: 'var(--mut2)', fontSize: '14px', lineHeight: '1.6' }}>
              <h4 style={{ color: '#fff', marginBottom: '10px', fontSize: '16px' }}>About Dev Studio</h4>
              <p>Dev Studio provides professional website development and web designing services. We help small businesses, freelancers, and professionals build fast, responsive, and modern websites to establish their strong digital presence.</p>
            </div>

            {/* 🚀 NEW: React Router Links for Legal Pages */}
            <div style={{ display: 'flex', justifyContent: 'center', gap: '24px', marginBottom: '20px', flexWrap: 'wrap' }}>
              <Link to="/contact-us" style={{ color: 'var(--mut2)', fontSize: '13px', fontWeight: 600, textDecoration: 'none', transition: '0.2s' }} onMouseEnter={e => e.target.style.color='#fff'} onMouseLeave={e => e.target.style.color='var(--mut2)'}>Contact Us</Link>
              <Link to="/privacy-policy" style={{ color: 'var(--mut2)', fontSize: '13px', fontWeight: 600, textDecoration: 'none', transition: '0.2s' }} onMouseEnter={e => e.target.style.color='#fff'} onMouseLeave={e => e.target.style.color='var(--mut2)'}>Privacy Policy</Link>
              <Link to="/terms-and-conditions" style={{ color: 'var(--mut2)', fontSize: '13px', fontWeight: 600, textDecoration: 'none', transition: '0.2s' }} onMouseEnter={e => e.target.style.color='#fff'} onMouseLeave={e => e.target.style.color='var(--mut2)'}>Terms & Conditions</Link>
              <Link to="/refund-policy" style={{ color: 'var(--mut2)', fontSize: '13px', fontWeight: 600, textDecoration: 'none', transition: '0.2s' }} onMouseEnter={e => e.target.style.color='#fff'} onMouseLeave={e => e.target.style.color='var(--mut2)'}>Refund Policy</Link>
            </div>
            
            <p style={{ color: '#334155', fontSize: '13px', marginBottom: '6px' }}>This website (https://devstudiobuild.in) is owned and operated by Rakesh Kumar Maurya.</p>
            <p style={{ color: '#334155', fontSize: '13px', marginBottom: '12px' }}>Operating Address: Gram Nonar, Post Tulsi Ashram, Nonar, Chandauli, Uttar Pradesh - 232108</p>
            <p style={{ color: '#334155', fontSize: '13px' }}>© {new Date().getFullYear()} Dev Studio. Built for Founders by Devansh Studio.</p>
          </footer>
        </>
      )}
      
      {page === "auth" && (
        <AuthPage 
          initMode={authMode} 
          notify={notify} 
          onBack={() => setPage("landing")} 
          onAuth={u => { 
            setUser(u); 
            setPage("dashboard"); 
            notify(`Welcome back, ${u?.name || "User"}! 👋`, "success"); 
          }} 
        />
      )}
      
      {page === "dashboard" && user && (
        <Dashboard 
          user={user} 
          notify={notify} 
          onBack={() => setPage("landing")} 
          openUpgrade={openUpgrade} 
          onUpgradeClosed={() => setOpenUpgrade(false)}
          onLogout={handleLogout} 
        />
      )}
      
      <CookieBanner />
    </>
  );
}
