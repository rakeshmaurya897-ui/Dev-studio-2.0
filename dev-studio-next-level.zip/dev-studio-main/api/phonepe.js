export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method Not Allowed' });

  try {
    const { amount, planId, planName } = req.body;

    const clientId = process.env.PHONEPE_MERCHANT_ID;
    const clientSecret = process.env.PHONEPE_SALT_KEY;
    const clientVersion = process.env.PHONEPE_SALT_INDEX || '1';

    if (!clientId || !clientSecret) {
      return res.status(400).json({ error: "Vercel Keys missing!" });
    }

    // 🚀 स्टेप 1: PhonePe के नए V2 सिस्टम से सिक्योर Auth Token लेना
    const tokenParams = new URLSearchParams();
    tokenParams.append('client_id', clientId);
    tokenParams.append('client_secret', clientSecret);
    tokenParams.append('client_version', clientVersion);
    tokenParams.append('grant_type', 'client_credentials');

    const tokenRes = await fetch("https://api.phonepe.com/apis/identity-manager/v1/oauth/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: tokenParams.toString()
    });

    const tokenData = await tokenRes.json();
    if (!tokenData.access_token) {
      return res.status(400).json({ error: "Auth Error: PhonePe ने Keys रिजेक्ट कर दीं।" });
    }

    const transactionId = 'TXN' + Date.now();

    // 🚀 स्टेप 2: नया V2 पेमेंट पेलोड (Payload) भेजना
    const payPayload = {
      merchantOrderId: transactionId,
      amount: amount * 100, // PhonePe इसे पैसे (paise) में लेता है
      paymentFlow: {
        type: "PG_CHECKOUT",
        merchantUrls: {
          redirectUrl: `https://devstudiobuild.in/api/phonepe-status?id=${transactionId}&planId=${planId}&amount=${amount}`,
          cancelUrl: `https://devstudiobuild.in/?payment=failed`
        }
      }
    };

    const payRes = await fetch("https://api.phonepe.com/apis/pg/checkout/v2/pay", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `O-Bearer ${tokenData.access_token}`
      },
      body: JSON.stringify(payPayload)
    });

    const payData = await payRes.json();
    
    const redirectUrl = payData.redirectUrl || (payData.data && payData.data.redirectUrl) || (payData.data && payData.data.instrumentResponse && payData.data.instrumentResponse.redirectInfo && payData.data.instrumentResponse.redirectInfo.url);

    if (payRes.ok && redirectUrl) {
      return res.status(200).json({ url: redirectUrl });
    } else {
      return res.status(400).json({ error: `PhonePe Pay Error: ${payData.message || 'Failed to generate link'}` });
    }

  } catch (error) {
    return res.status(500).json({ error: `Server Issue: ${error.message}` });
  }
}
